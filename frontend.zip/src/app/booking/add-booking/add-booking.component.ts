import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AirlineInventory } from 'src/app/models/airline-inventory';
import { FlightBooking } from 'src/app/models/flight-booking';
import { AirlineService } from 'src/app/services/airline.service';
import { BookingService } from 'src/app/services/booking.service';
import { RouterService } from 'src/app/services/router/router.service';
import { UserService } from 'src/app/services/user.service';

import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-booking',
  templateUrl: './add-booking.component.html',
  styleUrls: ['./add-booking.component.css']
})
export class AddBookingComponent implements OnInit {
inventoryObj?:AirlineInventory[];
airlineInventory:AirlineInventory;
searchInventories?:AirlineInventory[];
flightBooking?:FlightBooking;
searchForm:FormGroup;
selectFromPlace?:any;
selecttoPlace?:any;
flightNumber?:string;
usermailId?:string;
isResultBySearch:boolean=false;
userId?:string;
  constructor(private routerService:RouterService,private airlineService:AirlineService,private bookingService:BookingService,private formBuilder:FormBuilder,private userService:UserService) { 
    this.airlineInventory=new AirlineInventory();
    this.flightBooking=new FlightBooking();
    this.searchForm=formBuilder.group({
      fromPlace: ["", Validators.compose([Validators.required, Validators.minLength(2)])],
      toPlace: ["", Validators.compose([Validators.required, Validators.minLength(2)])],
    });
  }

  ngOnInit(): void {
    this.airlineService.getAllInventoryDetails().subscribe((inventoryObj:AirlineInventory[]) => {
      this.inventoryObj =inventoryObj;
    });
  }
  searchAirline(){
   
    let fromPlace:string=this.selectFromPlace;
    let toPlace:string=this.selecttoPlace;
    this.airlineService.getAirlinesBySearch(fromPlace,toPlace).subscribe((searchInventoryObj:AirlineInventory[])=>{
this.searchInventories=searchInventoryObj;
this.isResultBySearch=true;
    });

  }
  reset()
  {this.isResultBySearch=false}
  

  bookAirline(flightNumber: any,fromPlace:any,toPlace:any,startDate:any,endDate:any) {
    this.userId=this.routerService.getUserId() as string;
    this.usermailId=localStorage.getItem('UserEmail') as string;
  this.flightBooking=new FlightBooking(0,0,parseInt(this.userId),flightNumber,this.usermailId,fromPlace,toPlace,startDate,endDate,false);

 
    this.bookingService.bookAirline(this.flightBooking).subscribe({
      next: (res) => {
        if (res == true) {
          
          Swal.fire('Airline Booked Successfully!!!', 'Booking Done', 'success')
          this.routerService.gotoBookingHistory();
        }

      },

      error: (e) => {
        Swal.fire('Airline Booking failed', 'Booking Failed', 'error')

      },
    });

  }

}