import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FlightBooking } from 'src/app/models/flight-booking';
import { BookingService } from 'src/app/services/booking.service';
import { RouterService } from 'src/app/services/router/router.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-manage-booking',
  templateUrl: './manage-booking.component.html',
  styleUrls: ['./manage-booking.component.css']
})
export class ManageBookingComponent implements OnInit {
  flightBookings?:FlightBooking[];
  searchForm:FormGroup;
  pnrNo?:any;
  isResultBySearch:boolean=false;
  constructor(private routerService:RouterService,private bookingService:BookingService,private formBuilder:FormBuilder) { 
   
    this.searchForm=formBuilder.group({
      pnrNo: ["", Validators.compose([Validators.required, Validators.minLength(2)])]
    });
  }

  ngOnInit(
    
  ): void {  }
  reset()
  {this.isResultBySearch=false}
  searchBookingByPnr(){
    let pnNo:string=this.pnrNo;
    this.bookingService.getBookingHistoryByPnr(parseInt(pnNo)).subscribe((flightBookingObj:FlightBooking[])=>{
      this.flightBookings=flightBookingObj;
      this.isResultBySearch=true;
          });
      
  }
  deleteBooking(pnrNo:any,startDate:any){
    let dateCheckOut = startDate;
        let dateToBeCheckOut = new Date(dateCheckOut);
        let today = new Date();
        today.setDate( today.getDate() -1 );
        if(today<dateToBeCheckOut){
    this.bookingService.deleteBookingByPnrNo(parseInt(pnrNo)).subscribe({
      next: (res) => {
        if (res == true) {
          
          Swal.fire('Booking Deleted Successfully!!!', 'Booking Deleted', 'success')
          this.isResultBySearch=false;
          this.routerService.gotoManageBooking();
        }

      },

      error: (e) => {
        Swal.fire('Booking Delete failed', 'Deleting Failed', 'error')

      },

    });
  }
  else{
    Swal.fire('Cancelation failed', 'Booking Time Exceeded', 'error')
  }
  }
  }


