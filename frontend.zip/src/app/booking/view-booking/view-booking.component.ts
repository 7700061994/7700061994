import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FlightBooking } from 'src/app/models/flight-booking';
import { BookingService } from 'src/app/services/booking.service';
import { RouterService } from 'src/app/services/router/router.service';

@Component({
  selector: 'app-view-booking',
  templateUrl: './view-booking.component.html',
  styleUrls: ['./view-booking.component.css']
})
export class ViewBookingComponent implements OnInit {
  flightBookings?:FlightBooking[];
  searchForm:FormGroup;
  emailId?:any;
  isResultBySearch:boolean=false;
  constructor(private routerService:RouterService,private bookingService:BookingService,private formBuilder:FormBuilder) { 
   
    this.searchForm=formBuilder.group({
      emailId: ["", Validators.compose([Validators.required, Validators.minLength(2)])]
    });
  }
  ngOnInit(): void {
  }
  reset()
  {this.isResultBySearch=false}
  searchBookingByEmailId(){
    let emailId:string=this.emailId;
    this.bookingService.getBookingHistoryByEmailId(emailId).subscribe((flightBookingObj:FlightBooking[])=>{
      this.flightBookings=flightBookingObj;
      this.isResultBySearch=true;
          });
      
  }
}
