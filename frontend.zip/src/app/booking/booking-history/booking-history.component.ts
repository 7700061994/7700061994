import { Component, OnInit } from '@angular/core';
import { FlightBooking } from 'src/app/models/flight-booking';
import { BookingService } from 'src/app/services/booking.service';
import { RouterService } from 'src/app/services/router/router.service';

@Component({
  selector: 'app-booking-history',
  templateUrl: './booking-history.component.html',
  styleUrls: ['./booking-history.component.css']
})
export class BookingHistoryComponent implements OnInit {
  flightBookingObj?:FlightBooking[];
  userId?:string;
  constructor(private routerService:RouterService,private bookingService:BookingService) { }

  ngOnInit(): void {
    this.userId=this.routerService.getUserId() as string;
      
    this.bookingService.getBookingHistoryById(parseInt(this.userId)).subscribe((flightBooking:FlightBooking[])  => {
   this.flightBookingObj=  flightBooking;
     });
  }
}


