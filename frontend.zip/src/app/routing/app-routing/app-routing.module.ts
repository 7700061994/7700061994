import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { RegisterComponent } from 'src/app/component/register/register.component';
import { LoginComponent } from 'src/app/component/login/login.component';
import { AddAirlineComponent } from 'src/app/airline/add-airline/add-airline.component';
import { DisplayAirlineComponent } from 'src/app/airline/display-airline/display-airline.component';

import { AuthGuard } from 'src/app/guard/auth.guard';
import { LogoutComponent } from 'src/app/component/logout/logout.component';
import { UserNavComponent } from 'src/app/component/user-nav/user-nav.component';
import { NavComponent } from 'src/app/component/nav/nav.component';
import { AdminNavComponent } from 'src/app/component/admin-nav/admin-nav.component';
import { AddInventoryComponent } from 'src/app/airline/add-inventory/add-inventory.component';
import { DisplayInventoryComponent } from 'src/app/airline/display-inventory/display-inventory.component';
import { AddBookingComponent } from 'src/app/booking/add-booking/add-booking.component';
import { ManageBookingComponent } from 'src/app/booking/manage-booking/manage-booking.component';
import { BookingHistoryComponent } from 'src/app/booking/booking-history/booking-history.component';


const routes:Routes=[
 
  {path:'',component:NavComponent,children:[{path:'register',component:RegisterComponent}]},
  {path:'',component:NavComponent,children:[{path:'login',component:LoginComponent}]},
  {path:'',component:AdminNavComponent,children:[{ path: 'add-airline', component: AddAirlineComponent,canActivate: [AuthGuard]}] },
  {path:'',component:AdminNavComponent,children:[{ path: 'add-inventory', component: AddInventoryComponent,canActivate: [AuthGuard]}] },
  {path:'',component:AdminNavComponent,children:[{ path: 'display-inventory', component: DisplayInventoryComponent,canActivate: [AuthGuard]}] },
  {path:'',component:AdminNavComponent,children:[{ path: 'display-airline', component: DisplayAirlineComponent,canActivate: [AuthGuard]}] },
  {path:'',component:AdminNavComponent,children:[{ path: 'view-booking', component: DisplayAirlineComponent,canActivate: [AuthGuard]}] },
   {path:'',component:UserNavComponent,children:[{ path: 'add-booking', component: AddBookingComponent,canActivate: [AuthGuard]}] },
  {path:'',component:UserNavComponent,children:[{ path: 'manage-booking', component: ManageBookingComponent,canActivate: [AuthGuard]}] },
  {path:'',component:UserNavComponent,children:[{ path: 'booking-history', component: BookingHistoryComponent,canActivate: [AuthGuard]}] },
 
  { path: 'logout', component: LogoutComponent },
  { path: 'login', component: LoginComponent, pathMatch: "full" }
]
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],exports:[RouterModule]
})
export class AppRoutingModule { }
