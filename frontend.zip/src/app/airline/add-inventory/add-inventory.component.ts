import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidatorFn, Validators } from '@angular/forms';

import { AirlineInventory } from 'src/app/models/airline-inventory';
import { Airlines } from 'src/app/models/airlines';
import { AirlineService } from 'src/app/services/airline.service';
import { RouterService } from 'src/app/services/router/router.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-inventory',
  templateUrl: './add-inventory.component.html',
  styleUrls: ['./add-inventory.component.css']
})
export class AddInventoryComponent implements OnInit {
  airlines?: Airlines[];
 
   inventoryObj:AirlineInventory;
  scheduledays=['Daily','Sun','Mon','Tue','Wed','Thru','Fri','Sat','WeekDays','WeekEnds'];
 meals=['Non-Veg','Veg'];
  AddInventoryForm:FormGroup;
  constructor(private  airlineService:AirlineService,private routerService:RouterService,private formBuilder:FormBuilder ) {
    this.inventoryObj=new AirlineInventory();
    this.AddInventoryForm=formBuilder.group({
      flightNumber: ["", Validators.compose([Validators.required, Validators.minLength(3)])],
      airlineName: ["", Validators.compose([Validators.required, Validators.minLength(3)])],
      fromPlace: ["", Validators.compose([Validators.required, Validators.minLength(2)])],
      toPlace: ["", Validators.compose([Validators.required, Validators.minLength(2)])],
      bussinessSeats: ["", Validators.compose([Validators.required, Validators.minLength(1)])],
      bussinessSeatPrice: ["", Validators.compose([Validators.required, Validators.minLength(2)])],
      nonBussinessSeats: ["", Validators.compose([Validators.required, Validators.minLength(2)])],
      nonBussinessSeatPrice: ["", Validators.compose([Validators.required, Validators.minLength(1)])],
      noOfRow: ["", Validators.compose([Validators.required, Validators.minLength(2)])],
      meal: ["", Validators.compose([Validators.required, Validators.minLength(2)])],
      scheduledDays: ["", Validators.compose([Validators.required, Validators.minLength(1)])],
      instrumentUsed: ["", Validators.compose([Validators.required, Validators.minLength(2)])],
      endDate: ['', Validators.required ],
      startDate: ['', Validators.required ]
    }, {validators: this.dateLessThan('startDate', 'endDate')
  
    })   
}
   dateLessThan(from: string, to: string) {
     debugger;
    return (group: FormGroup): {[key: string]: any} => {
     let f = group.controls[from];
     let t = group.controls[to];
     if (f.value > t.value) {
       return {
         dates: "Date from should be less than Date to"
       };
     }
     return {};
    }
  }
    ngOnInit(): void {
    this.airlineService.getAllAirlines().subscribe((airlines:Airlines[]) => {
      this.airlines =airlines;
    });
  }
  addinventory(AddInventoryForm:FormGroup) {
    this.inventoryObj=AddInventoryForm.value;
    
    this.airlineService.addInventory(this.inventoryObj).subscribe({
      next: (res) => {
        if (res == true) {
          Swal.fire('Inventory added Successfully!!', 'Add Inventory', 'success')
          this.routerService.gotoDisplaySchedules();
        }
       
      },

      error: (e) => {
        Swal.fire('Schedule Registration failed', 'Add Inventory', 'error')
       
      },
    });

}}
