import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AirlineInventory } from 'src/app/models/airline-inventory';
import { Airlines } from 'src/app/models/airlines';

import { AirlineService } from 'src/app/services/airline.service';
import { RouterService } from 'src/app/services/router/router.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-display-airline',
  templateUrl: './display-airline.component.html',
  styleUrls: ['./display-airline.component.css']
})
export class DisplayAirlineComponent implements OnInit {
  airlines?: Airlines[];
  airlineName?: string;
  constructor(private airlineService: AirlineService, private routerService: RouterService) {

  }

  ngOnInit(): void {
    this.loadAirline();

  }
  AddAirline() {
    this.routerService.gotoAddAirline();
  }
  loadAirline() {
    this.airlineService.getAllAirlines().subscribe((airlines: Airlines[]) => {
      this.airlines = airlines;
    });
  }
  blockAirline(airlineName: any) {

    this.airlineService.blockAirline(airlineName).subscribe({

      next: (res) => {
        if (res == true) {
          this.loadAirline();
          Swal.fire('Airline blocked Successfully!!', 'Block Airline', 'success')
        }

      },

      error: (e) => {
        Swal.fire('Airline Blocked failed', 'Block Airline', 'error')

      },
    });

  }

  unBlockAirline(airlineName: any) {

    this.airlineService.unBlockAirline(airlineName).subscribe({
      next: (res) => {
        if (res == true) {
          this.loadAirline();
          Swal.fire('Airline Unblocked Successfully!!', 'Block Airline', 'success')

        }

      },

      error: (e) => {
        Swal.fire('Airline Blocked failed', 'Block Airline', 'error')

      },
    });

  }

}



