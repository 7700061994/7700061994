import { Component, OnInit } from '@angular/core';
import { AirlineInventory } from 'src/app/models/airline-inventory';
import { AirlineService } from 'src/app/services/airline.service';

@Component({
  selector: 'app-display-inventory',
  templateUrl: './display-inventory.component.html',
  styleUrls: ['./display-inventory.component.css']
})
export class DisplayInventoryComponent implements OnInit {
inventories?:AirlineInventory[];
  constructor(private airlineService:AirlineService) { }

  ngOnInit(): void {
    this.airlineService.getAllInventoryDetails().subscribe((inventories:AirlineInventory[]) => {
      this.inventories =inventories;
    });
  }

}
