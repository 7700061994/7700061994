import { Component, OnInit } from '@angular/core';
import { Airlines } from 'src/app/models/airlines';
import Swal from 'sweetalert2';
import { AirlineService } from 'src/app/services/airline.service';
import { RouterService } from 'src/app/services/router/router.service';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-add-airline',
  templateUrl: './add-airline.component.html',
  styleUrls: ['./add-airline.component.css']
})
export class AddAirlineComponent implements OnInit {
 
  airlineObj: Airlines;
  AddAirlineForm:FormGroup;
  
  constructor(private formBuilder: FormBuilder ,private airlineService: AirlineService, private routerService:RouterService,private httpclient:HttpClient) {
    this.airlineObj = new Airlines();
    
    this.AddAirlineForm = formBuilder.group({
      airlineName: ["", Validators.compose([Validators.required, Validators.minLength(3)])],
      airlineAddress: ["", Validators.compose([Validators.required, Validators.minLength(2)])],
      contactNo: ["", Validators.compose([Validators.required, Validators.minLength(2)])]
    });
 
  }
  ngOnInit(): void {
  }
  addairline(AddAirlineForm:FormGroup) {
    this.airlineObj=AddAirlineForm.value;
    
    this.airlineService.addAirline(this.airlineObj).subscribe({
      next: (res) => {
        if (res == true) {
          Swal.fire('Airline added Successfully!!', 'Add Airline', 'success')
          this.routerService.gotoDisplayAirline();
        }
       
      },

      error: (e) => {
        Swal.fire('Airline Registration failed', 'failed reg', 'error')
       
      },
    });

  }
}
