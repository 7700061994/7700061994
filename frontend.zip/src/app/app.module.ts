import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { HeaderComponent } from './component/header/header.component';
import { FooterComponent } from './component/footer/footer.component';

import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatToolbarModule} from '@angular/material/toolbar';
import { NavComponent } from './component/nav/nav.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { RegisterComponent } from './component/register/register.component';
import { LoginComponent } from './component/login/login.component';
import { AppRoutingModule } from './routing/app-routing/app-routing.module';
import {MatCardModule} from '@angular/material/card';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatInputModule} from '@angular/material/input';
import { LogoutComponent } from './component/logout/logout.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { DisplayAirlineComponent } from './airline/display-airline/display-airline.component';
import { AddAirlineComponent } from './airline/add-airline/add-airline.component';
import {MatRadioModule} from '@angular/material/radio';


import { UserNavComponent } from './component/user-nav/user-nav.component';
import { AdminNavComponent } from './component/admin-nav/admin-nav.component';
import { AddInventoryComponent } from './airline/add-inventory/add-inventory.component';
import { NgxMatDatetimePickerModule, 
  NgxMatNativeDateModule, 
  NgxMatTimepickerModule  } from '@angular-material-components/datetime-picker';
import { DisplayInventoryComponent } from './airline/display-inventory/display-inventory.component';
import { AddBookingComponent } from './booking/add-booking/add-booking.component';
import { ManageBookingComponent } from './booking/manage-booking/manage-booking.component';
import { BookingHistoryComponent } from './booking/booking-history/booking-history.component';
import { ViewBookingComponent } from './booking/view-booking/view-booking.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    NavComponent,
    RegisterComponent,
    LoginComponent,
    LogoutComponent,
    DisplayAirlineComponent,
    AddAirlineComponent,
   
    UserNavComponent,
    AdminNavComponent,
    AddInventoryComponent,
    DisplayInventoryComponent,
    AddBookingComponent,
    ManageBookingComponent,
    BookingHistoryComponent,
    ViewBookingComponent,
   
  ],
  imports: [
    BrowserModule,HttpClientModule, BrowserAnimationsModule,MatToolbarModule, LayoutModule,
     MatButtonModule, MatSidenavModule, MatIconModule, MatListModule,
     AppRoutingModule,MatCardModule,MatExpansionModule,MatInputModule,FormsModule,
     ReactiveFormsModule,
     MatFormFieldModule,MatRadioModule,NgxMatDatetimePickerModule, 
     NgxMatNativeDateModule, 
     NgxMatTimepickerModule 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
