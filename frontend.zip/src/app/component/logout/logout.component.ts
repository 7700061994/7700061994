import { Component, OnInit } from '@angular/core';
import { RouterService } from 'src/app/services/router/router.service';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {
  constructor(private routerService: RouterService) { }

  ngOnInit(): void {
    this.routerService.clearTokenStorage();
    Swal.fire('User Logout Successfully', 'Logout', 'success');
    this.routerService.gotoLogin();

  }

}
