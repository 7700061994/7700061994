export class UserInfo {

    name?: string;
    password?: string;
    role?:string;
}
