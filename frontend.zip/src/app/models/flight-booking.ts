export class FlightBooking {
    constructor(
   public id ?:number,
   public  pnrNo ?:number,
   public userId?:number,
   public flightNo?:string, 
   public emailId?:string,
   public fromPlace?:string,
   public toPlace?:string,
   public startDate?:string,
   public endDate?:string,
   public  isCancel?:boolean,
    ){}
   
}

