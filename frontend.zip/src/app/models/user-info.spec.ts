import { UserInfo } from './user-info';

describe('UserInfo', () => {
  it('should create an instance', () => {
    expect(new UserInfo()).toBeTruthy();
  });
});
