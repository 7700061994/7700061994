import { Time } from "@angular/common";

export class AirlineInventory {
    id?:number;
    airlineName?:string;
    flightNumber?:string;
   fromPlace?:string;
    toPlace?:string; 
    bussinessSeats?:number;
    bussinessSeatPrice?:number;
    nonBussinessSeats?:number;
    nonBussinessSeatPrice?:number;
    noOfRow?:number;
    meal?:string;
    scheduledDays?:string;
    instrumentUsed?:string;
    isBlocked?:boolean;
    startDate?:string;
    endDate?:string;
    
}
