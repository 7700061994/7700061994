import { AirlineInventory } from './airline-inventory';

describe('AirlineInventory', () => {
  it('should create an instance', () => {
    expect(new AirlineInventory()).toBeTruthy();
  });
});
