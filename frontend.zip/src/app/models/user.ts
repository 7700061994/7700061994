export class User {

    id?: number;
    firstName?: string;
    lastName?:string;
    age?:number;
    gender?:string;
    mobileNo?:number;
    emailId?:string;
    password?: string;
    isDeleted?: boolean;
    role?: string;
}
