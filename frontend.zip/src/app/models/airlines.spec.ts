import { Airlines } from './airlines';

describe('Airlines', () => {
  it('should create an instance', () => {
    expect(new Airlines()).toBeTruthy();
  });
});
