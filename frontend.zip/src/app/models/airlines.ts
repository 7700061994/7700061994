export class Airlines {
    id?:number;
    airlineName?:string;
    airlineAddress?: string;
    contactNo?:string;
    isBlocked?:boolean;
    
   
}
