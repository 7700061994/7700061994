import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { FlightBooking } from '../models/flight-booking';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class BookingService {

  tempBookingToAddInBackdend:FlightBooking[]=[];

  constructor(private httpClient:HttpClient) { }
  bookAirline(bookingObj:FlightBooking):Observable<boolean> {
    this.tempBookingToAddInBackdend?.push(bookingObj);
    return this.httpClient.post<boolean>('https://localhost:5005/api/Booking/addBooking',  this.tempBookingToAddInBackdend)
  }
  getBookingHistoryById(userId: number):Observable<Array<FlightBooking>> {
    return this.httpClient.get<Array<FlightBooking>>(`https://localhost:5005/api/Booking/getBookingHistoryByUserId/${userId}`);
 
  }
  getBookingHistoryByPnr(pnrNo: number):Observable<Array<FlightBooking>> {
    return this.httpClient.get<Array<FlightBooking>>(`https://localhost:5005/api/Booking/getBookingHistoryByPnrNo/${pnrNo}`);
 
  }
  getBookingHistoryByEmailId(emailId: string):Observable<Array<FlightBooking>> {
    return this.httpClient.get<Array<FlightBooking>>(`https://localhost:5005/api/Booking/getBookingHistoryByEmailid/${emailId}`);
 
  }
  deleteBookingByPnrNo(pnrNo: number):Observable<boolean> {
    return this.httpClient.delete<boolean>(`https://localhost:5005/api/Booking/deleteBookingByPnrNo/${pnrNo}`);
 
  }
}
