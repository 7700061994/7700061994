import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { JwtHelperService} from '@auth0/angular-jwt'



@Injectable({
  providedIn: 'root'
})
export class RouterService {
 
  
   jwt = new JwtHelperService();
   private DecodeUserToken:any;
  DecodeToken(userToken: any) {
    this.DecodeUserToken=this.jwt.decodeToken(userToken);
    localStorage.setItem('UserId',this.DecodeUserToken.unique_name)
  }
 
  gotoDisplaySchedules() {
    this.router.navigate(['display-inventory']);
  }
  gotoManageBooking() {
    this.router.navigate(['manage-booking']);
  }
  gotoBookingHistory() {
    this.router.navigate(['booking-history']);
  }
  DisplayUser() {
    this.router.navigate(['display-users']);
  }
  gotoDisplayBooking() {
    this.router.navigate(['display-booking']);
  }
  gotoAddBooking() {
    this.router.navigate(['add-booking']);
  }
  gotoAddAirline() {
    this.router.navigate(['add-airline']);
  }
  gotoBlockAirline() {
    this.router.navigate(['block-airline']);
  }
  gotoDisplayAirline() {
    this.router.navigate(['display-airline']);
  }
 
  gotoAirline() {
    this.router.navigate(['login']);
  }
gotoDashBoard(){
  this.router.navigate(['dashboard']);
}
  constructor(private router: Router) {
    
   }

  gotoLogin() {
    this.router.navigate(['login']);
  }
  gotoRegister() {
    this.router.navigate(['register']);
  }

  setUserToken(userToken: any) {
    localStorage.setItem('TOKEN', userToken)
 
  }
  getUserToken() {

    return localStorage.getItem('TOKEN');
  }
  getUserId()
  {
    return localStorage.getItem('UserId');
  }
  clearTokenStorage() {
    localStorage.clear();
  }
 
 


logout() {                           
  this.clearTokenStorage();
  this.router.navigate(['/login']);
}
}
