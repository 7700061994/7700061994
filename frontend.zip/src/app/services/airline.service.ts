import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Airlines } from '../models/airlines';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AirlineInventory } from '../models/airline-inventory';

@Injectable({
  providedIn: 'root'
})
export class AirlineService {
 
 
  tempAirlinesToAddInBackdend?: Airlines[]=[];
  tempInventoryToAddInBackend?: AirlineInventory[]=[];
  tempInventoryPlace?:AirlineInventory[]=[];

  constructor(private httpClient: HttpClient) {
  }
  getAllInventoryDetails(): Observable<Array<AirlineInventory>> {
    // API URL
    return this.httpClient.get<Array<AirlineInventory>>('https://localhost:5007/api/Airline/getAllInventoryDetails')
   
  }
  getAirlinesBySearch(fromPlace: any, toPlace: any): Observable<Array<AirlineInventory>> {
    return this.httpClient.get<Array<AirlineInventory>>(`https://localhost:5007/api/Airline/getAirlinesBySearch?fromPlace=${fromPlace}&toPlace=${toPlace}`)
   
  }
  
  getAllAirlines(): Observable<Array<Airlines>> {
    // API URL
    return this.httpClient.get<Array<Airlines>>('https://localhost:5007/api/Airline/getAllAirlines')
   
  }
  addAirline(airlineObj: Airlines): Observable<boolean> {
   this.tempAirlinesToAddInBackdend?.push(airlineObj);
   
    return this.httpClient.post<boolean>('https://localhost:5007/api/Airline/addAirline',  this.tempAirlinesToAddInBackdend)
      
  }
  addInventory(inventoryObj: AirlineInventory):Observable<boolean> {
    this.tempInventoryToAddInBackend?.push(inventoryObj);
   
    return this.httpClient.post<boolean>('https://localhost:5007/api/Airline/addInventory',  this.tempInventoryToAddInBackend)
     
  }

  unBlockAirline(airlineName:string):Observable<boolean> {
    
     return this.httpClient.get<boolean>(`https://localhost:5007/api/Airline/unBlockAirlineByName/${airlineName}`);
    }
    
  blockAirline(airlineNam:string):Observable<boolean> {
    

   return this.httpClient.get<boolean>(`https://localhost:5007/api/Airline/blockAirlineByName/${airlineNam}`);
  }


}
