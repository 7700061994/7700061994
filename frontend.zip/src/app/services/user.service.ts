
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../models/user';
import { UserInfo } from '../models/user-info';
import { RouterService } from './router/router.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {
   constructor(private httpClient: HttpClient, private routerService: RouterService) { }
  registerUser(user: User): Observable<boolean> {
    return this.httpClient.post<boolean>('https://localhost:5003/v1/api/User/register', user);

  }
  login(userInfo: UserInfo): Observable<string> {

    return this.httpClient.post<string>('https://localhost:5003/v1/api/User/login', userInfo);

  }
  getRoleById(userId: string): Observable<boolean> {
    return this.httpClient.get<boolean>(`https://localhost:5003/v1/api/User/GetRoleById/${userId}`);
  }
  getEmailbyUserId(userId: number): Observable<string> {
    return this.httpClient.get(`https://localhost:5003/v1/api/User/getEmailById/${userId}`, { responseType: 'text' });
  }

}