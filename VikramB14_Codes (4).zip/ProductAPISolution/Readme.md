# USerAPI
 * Admin
 * User



# USER API------------------------------UserManagementDb
  
  Applciation:
    * Register
    * Login------------------------->Token------------>sent to Frontend
           -----userId or userName



# Airline API---------------------------AirllineManagementDb
  Appliation:
    * AddAirline
    * CRUD


# Booking:





Angular|Web Application
        --------------------------

        Login---------------------------success---User
        ----------->Token------------>sent to Frontend
           -----userId or userName

        localstorage.SetItem('USERNAME',valueof userName)


        Search Flight Deatals--------->Booking
        -----------  --------------    -------------

        ---Book----   ----Book----    -----Book----

        this.userId=parseInt(localstorage.getItem('USERNAME'))
     BookingAPI---------------------------------------------BookingManagementDb
     HttpPost
     public ActionResult Booking([FromBody]Booking Booking)


     class Booking{
      
        public int Id
        public string UserName{get;set;}
        public long MobileNumber{get;set;}
        public strig EmailId{get;set;}

        List<Passenger>Passengers{get;set}
        [{},{}]
     }


     Bookings-----Table

     generatePNR
     Email Address


     -------------------------------------------------------
                                                BookingHistory

     -------------------------------------------------------

     this.localstroage.GetItem('USERNAME')

     if(empty){
          gotoLogin()
     }

     BookingAPI Backend Applcaition
     [HttpGet]
     getBookingsByEmailAddress(emailadderess)
     {

     }

     frontened:
     this.http.get(`localhost://5009/api/booking/getAllBookings/{emailadderess}`,headers:[Bearer:{this.localstorage.getItem('TOKEN'}])
     {

     }


     }











     }






     DB----->BookingAPI----->BookingManagementDb--------5009
                            Repository--->Insert------BookingManagementDb
             List<Booking> GetAllBookings()  

     RecommendationEngine<-------------BookingManagementDb
           * 5009
           * HttpClient---->List<Booking>

           * GetAllBookings()
             * StartLogic-------LINQ



     * List<Category>GetAllCategories(){

       }

       this.categoyselected="BNG";
       localstorage.setItem("USERCITY",this.categoyselected);



       # Validate Token
       # Test Cases
       # relations
       



