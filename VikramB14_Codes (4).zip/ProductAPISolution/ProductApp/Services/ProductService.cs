﻿using ProductApp.Exceptions;
using ProductApp.Models;
using ProductApp.Repository;
using System.Collections.Generic;

namespace ProductApp.Services
{
    public class ProductService : IProductService
    {
        readonly IProductRepository _productRepository;
        public ProductService(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }
        //public bool AddProduct(Product product)
        //{
        //    bool addProductStatus = false;
        //    Product productExist = _productRepository.GetProductByName(product.Name);
        //    if (productExist == null)
        //    {
        //        int addProductResult = _productRepository.AddProduct(product);
        //        if (addProductResult == 1)
        //        {
        //            addProductStatus = true;
        //        }
        //        else
        //        {
        //            addProductStatus = false;
        //        }
        //    }
        //    else
        //    {
        //        throw new ProductAlreadyExistException($"Product Already Exist!!!");
        //    }
        //    return addProductStatus;
        //}

        public Product GetProductByName(string name)
        {
            return _productRepository.GetProductByName(name);
        }

        public bool DeleteProductById(int id)
        {
            Product product = _productRepository.GetProductById(id);
            if (product != null)
            {
                int deleteProductResult = _productRepository.DeleteProduct(product);
                if (deleteProductResult == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                throw new ProductNotFoundException($"Product with ID::{id} details Not Found!!");
            }

        }

        public bool DeleteProductByName(string name)
        {
            Product product = _productRepository.GetProductByName(name);
            if (product != null)
            {
                int delteProductResult = _productRepository.DeleteProduct(product);
                if (delteProductResult == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                throw new ProductNotFoundException($"Product with Name::{name} details Not Found!!");
            }
        }

        public List<Product> GetAllProducts()
        {
            return _productRepository.GetAllProducts();
        }

        public Product UpdateProduct(int id, Product product)
        {
            Product updatedProduct = _productRepository.UpdateProduct(id, product);
            return updatedProduct;
        }

        public bool AddProducts(Product[] products)
        {
            return _productRepository.AddProducts(products);
        }
    }


}
