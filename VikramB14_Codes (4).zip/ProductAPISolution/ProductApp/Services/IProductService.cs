﻿using ProductApp.Models;
using System.Collections.Generic;

namespace ProductApp.Services
{
    public interface IProductService
    {
        List<Product> GetAllProducts();
        //bool AddProduct(Product product);
        Product UpdateProduct(int id, Product product);
        bool DeleteProductById(int id);
        bool DeleteProductByName(string name);
        bool AddProducts(Product[] products);
    }
}
