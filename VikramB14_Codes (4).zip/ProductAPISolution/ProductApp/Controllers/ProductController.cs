﻿using Microsoft.AspNetCore.Mvc;
using ProductApp.AOP;
using ProductApp.Models;
using ProductApp.Services;
using System.Collections.Generic;

namespace ProductApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ExceptionHandler]
    public class ProductController : ControllerBase
    {
        readonly IProductService _productService;
        public ProductController(IProductService productService)
        {
            _productService = productService;
        }

        [HttpGet]
        [Route("getAllProducts")]
        public ActionResult GetAllProducts()
        {
            List<Product> productList = _productService.GetAllProducts();
            return Ok(productList);
        }

        //[HttpPost]
        //[Route("addProduct")]
        //public ActionResult AddProduct([FromBody] Product product)
        //{
        //    bool addProductStatus = _productService.AddProduct(product);
        //    return Ok(addProductStatus);
        //}
        [HttpPost]
        [Route("addProducts")]
        public ActionResult AddProduct([FromBody] Product[] products)
        {
            bool addProductsStatus=_productService.AddProducts(products);
            return Ok(addProductsStatus); 
        }

        [HttpPut]
        [Route("updateProduct/{id:int}")]
        public ActionResult UpdateProduct(int id, [FromBody] Product product)
        {
            Product updatedProduct = _productService.UpdateProduct(id, product);
            return Ok(updatedProduct);
        }

        [HttpDelete]
        [Route("deleteProductById/{id:int}")]
        public ActionResult DelteProduct(int id)
        {
            bool deleteProductStatus = _productService.DeleteProductById(id);
            return Ok(deleteProductStatus);
        }
        [HttpDelete]
        [Route("deleteProductById/{name}")]
        public ActionResult DelteProduct(string name)
        {
            bool deleteProductStatus = _productService.DeleteProductByName(name);
            return Ok(deleteProductStatus);
        }
    }
}
