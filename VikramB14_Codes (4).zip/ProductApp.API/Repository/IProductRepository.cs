﻿using ProductApp.API.Models;
using System.Collections.Generic;

namespace ProductApp.API.Repository
{
    public interface IProductRepository
    {
        List<Product> GetAllProducts();
        Product GetProductByName(string productName);
        int AddProduct(Product product);
    }
}
