﻿using ProductApp.API.Context;
using ProductApp.API.Models;
using System.Collections.Generic;
using System.Linq;
namespace ProductApp.API.Repository
{
    public class ProductRepository : IProductRepository
    {
        readonly ProductDbContext _productDbContext;
        public ProductRepository(ProductDbContext productDbContext)
        {
            _productDbContext = productDbContext;
        }

        public int AddProduct(Product product)
        {
            var productList = _productDbContext.Products.AsQueryable();
            if (productList.Count() > 0)
            {
                product.Id = productList.Max(p => p.Id) + 1;
            }
            else
            {
                product.Id = 1;
            }
            _productDbContext.Products.Add(product);
            return _productDbContext.SaveChanges();
        }

        public List<Product> GetAllProducts()
        {
            return _productDbContext.Products.ToList();
        }

        public Product GetProductByName(string productName)
        {
            return _productDbContext.Products.Where(p => p.Name == productName).FirstOrDefault();
        }
    }
}
