﻿using ProductApp.API.Exceptions;
using ProductApp.API.Models;
using ProductApp.API.Repository;
using System.Collections.Generic;
namespace ProductApp.API.Services
{
    public class ProductService : IProductService
    {
        readonly IProductRepository _productRepository;

        public ProductService(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        public bool AddProduct(Product product)
        {
            var productExist = _productRepository.GetProductByName(product.Name);
            if (productExist == null)
            {
                var productAddResult = _productRepository.AddProduct(product);
                if (productAddResult == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                throw new ProductAlreadyExistException($"{product.Name} and Other Details Exist!!");
            }

        }

        public List<Product> GetAllProducts()
        {
            return _productRepository.GetAllProducts();
        }

        public Product GetProductByName(string productName)
        {
            return _productRepository.GetProductByName(productName);
        }

       
    }
}
