﻿using ProductApp.API.Models;
using System.Collections.Generic;

namespace ProductApp.API.Services
{
    public interface IProductService
    {
        List<Product> GetAllProducts();
        Product GetProductByName(string productName);
        bool AddProduct(Product product);
    }
}
