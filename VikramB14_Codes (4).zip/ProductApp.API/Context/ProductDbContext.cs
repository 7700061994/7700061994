﻿using Microsoft.EntityFrameworkCore;
using ProductApp.API.Models;

namespace ProductApp.API.Context
{
    public class ProductDbContext : DbContext
    {
        public ProductDbContext(DbContextOptions<ProductDbContext> options) : base(options)
        {
            Database.EnsureCreated();
        }


        public DbSet<Product> Products { get; set; }
    }
}
