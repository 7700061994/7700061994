﻿using Microsoft.AspNetCore.Mvc;
using ProductApp.API.AOP;
using ProductApp.API.Models;
using ProductApp.API.Services;

namespace ProductApp.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ExceptionHandler]
    public class ProductController : ControllerBase
    {
        readonly IProductService _proudctService;
        public ProductController(IProductService proudctService)
        {
            _proudctService = proudctService;
        }

        [HttpGet]
        [Route("getAllProducts")]
        public ActionResult GetAllProducts()
        {
            
            return Ok(_proudctService.GetAllProducts());
        }
        [HttpGet]
        [Route("getProductByName:productName")]
        public ActionResult GetProductById(string productName)
        {
            
            return Ok(_proudctService.GetProductByName(productName));
        }

        [HttpPost]
        [Route("addProduct")]
        public ActionResult AddProduct([FromBody] Product product)
        {
            bool addProductStatus = _proudctService.AddProduct(product);
            return Created("api/Created", addProductStatus);
        }

    }
}
