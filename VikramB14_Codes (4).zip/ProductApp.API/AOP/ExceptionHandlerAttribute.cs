﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using ProductApp.API.Exceptions;

namespace ProductApp.API.AOP
{
    public class ExceptionHandlerAttribute : ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            if (context.Exception.GetType() == typeof(ProductAlreadyExistException))
            {
                context.Result = new OkObjectResult(context.Exception.Message);
            }
            else if (context.Exception.GetType() == typeof(ProductNotFoundException))
            {
                context.Result = new OkObjectResult(context.Exception.Message);
            }

        }
    }
}
