﻿using System;

namespace ProductApp.API.Exceptions
{
    public class ProductAlreadyExistException : ApplicationException
    {
        public ProductAlreadyExistException()
        {

        }
        public ProductAlreadyExistException(string msg) : base(msg)
        {

        }
    }
}
