﻿using SendMicroServiceAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SendMicroServiceAPI.Repository
{
    public interface IUserRepository
    {
        Task SendDataToServiceBus();
        Task SendUserMessage();
        public List<User> GetDummyDataForUser();
    }
}
