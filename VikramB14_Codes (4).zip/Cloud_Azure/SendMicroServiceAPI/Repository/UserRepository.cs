﻿using Newtonsoft.Json;
using SendMicroServiceAPI.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Azure.ServiceBus;
using System.Text;

namespace SendMicroServiceAPI.Repository
{
    public class UserRepository : IUserRepository
    {
        static ITopicClient topicClient;
        public async Task SendDataToServiceBus()
        {
            string ServiceBusConnectionString = "Endpoint=sb://fullstackvikram.servicebus.windows.net/;SharedAccessKeyName=sender-sas-ploicy;SharedAccessKey=Q+AOTNfdh70mQYro0Mg4m4bzwcKyrA/CH1MvRUE5MJQ=";

            string TopicName = "sender-topic";

            topicClient = new TopicClient(ServiceBusConnectionString, TopicName);

            // Send messages.
            await SendUserMessage();

            //Console.ReadKey();

            await topicClient.CloseAsync();
        }
        public List<User> GetDummyDataForUser()
        {
            User user = new User();
            List<User> lstUsers = new List<User>();
            for (int i = 1; i < 3; i++)
            {
                user = new User();
                user.Id = i;
                user.Name = "Vikram...." + i;

                lstUsers.Add(user);
            }

            return lstUsers;
        }

        public async Task SendUserMessage()
        {
            List<User> users = GetDummyDataForUser();

            var serializeUser = JsonConvert.SerializeObject(users);

            string messageType = "userData";

            string messageId = Guid.NewGuid().ToString();

            var message = new ServiceBusMessage
            {
                Id = messageId,
                Type = messageType,
                Content = serializeUser
            };

            var serializeBody = JsonConvert.SerializeObject(message);

            // send data to bus

            var busMessage = new Message(Encoding.UTF8.GetBytes(serializeBody));
            busMessage.UserProperties.Add("Type", messageType);
            busMessage.MessageId = messageId;

            await topicClient.SendAsync(busMessage);

            //Console.WriteLine("message has been sent");
        }
    }
}
