﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SendMicroServiceAPI.Services;

namespace SendMicroServiceAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserSendController : ControllerBase
    {
        IUserService userService; 
        public UserSendController(IUserService _userService)
        {
            userService = _userService;
        }
        [HttpPost]
        [Route("senduserData")]
        public ActionResult SendDataToServiceBus()
        {
            userService.SendDataToServiceBus();
            return StatusCode(201, "Data Sent to Service Bus");
        }
    }
}
