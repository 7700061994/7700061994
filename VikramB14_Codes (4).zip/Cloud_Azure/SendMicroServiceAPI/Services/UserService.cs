﻿using SendMicroServiceAPI.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SendMicroServiceAPI.Services
{
    public class UserService : IUserService
    {
        IUserRepository userRepository;
        public UserService(IUserRepository _userRepository)
        {
            userRepository = _userRepository;
        }
        public void SendDataToServiceBus()
        {
            userRepository.SendDataToServiceBus().GetAwaiter().GetResult();
        }
    }
}
