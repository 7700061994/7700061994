# Azure ,AWS, GCP
# Microsoft Azure Cloud
  * [Azure Portal](https://portal.azure.com/)
  * [Azure Personal Account](https://azure.microsoft.com/en-us/)
    * Free account
    * paid account
  * Marketplace
  * Resource Groups
  * Azure Components
     * Physical Component 
        * Region: Physical Entity
     * Logical Component
        * Subscription------------------------->Free,Paid, Admin-provided subscription name
        * Resource Group Name-------------------Give Reosurce Group name
  * [Azure Calculator](https://azure.microsoft.com/en-us/pricing/calculator/)  * Azure Cloud??
      * Pay-As-You-Go
      * Renting Model
      * Zoom Car, Bikes,Yulu, 
      * Bangalore<--->Goa
         * 2 Days
      * 4 GB
      * 32GB RAM, 150 GB

      * Black Friday
 * HTML Resposive Design Cloud
   * Normal Server
   * BigRock, Hostgator, Hostingraja,Bluehost, Godaddy
     Hostinger
 *  Backend Application
    * App Services
      * Linux plan 
      * East-us
      * Code
      * .Net5 
      * https://weatherforecastapp.azurewebsites.net/
    * [Azure Data Studio](https://docs.microsoft.com/en-in/sql/azure-data-studio/download-azure-data-studio?view=sql-server-ver15)

    * https://userapiapp.azurewebsites.net/v1/api/User/getAllUsers


# Storage Accounts
  * Create Storage Account
  * Storage account

  * CDN (Content Delivery Network)

# Azure VM: Creating virutal version of something
   * ThinClient
   * Desktop Level virtualization
   * Minitors:10 CPUs
   * 1 CPU
   *  4 GB
      * 32GB RAM, 150 GB

# API Management Services
 * 1 hour 15 mins (Developer without SLA)

servername:userapivikram-server
username:userapivikram-server-admin
password:7TFIQE02HG317W65$

# Azure Functions 
  * FunctionApp
    * image---->storage account----image-------->

# Azure Service Bus


