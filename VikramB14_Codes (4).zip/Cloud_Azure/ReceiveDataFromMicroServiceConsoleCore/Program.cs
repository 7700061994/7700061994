﻿using Microsoft.Azure.ServiceBus;
using System;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ReceiveDataFromMicroServiceConsoleCore.Models;

namespace ReceiveDataFromMicroServiceConsoleCore
{
    class Program
    {
        static ISubscriptionClient subscriptionClient;

        static void Main(string[] args)
        {
            Console.WriteLine("Listner started.");
            MainAsync().GetAwaiter().GetResult();
        }

        static async Task MainAsync()
        {
            string ServiceBusConnectionString = "Endpoint=sb://fullstackvikram.servicebus.windows.net/;SharedAccessKeyName=listner-sas-policy;SharedAccessKey=8nq2HpkVgTzAeVr9YpIXuxU4H5kEIisrqzjGJ/8L7f4=";

            string TopicName = "sender-topic";
            string SubscriptionName = "vikram-subscription";

            subscriptionClient = new SubscriptionClient(ServiceBusConnectionString, TopicName, SubscriptionName);

            // Register subscription message handler and receive messages in a loop.
            RegisterOnMessageHandlerAndReceiveMessages();

            Console.ReadKey();

            await subscriptionClient.CloseAsync();
        }

        static void RegisterOnMessageHandlerAndReceiveMessages()
        {
            var messageHandlerOptions = new MessageHandlerOptions(ExceptionReceivedHandler);

            // Register the function that processes messages.
            subscriptionClient.RegisterMessageHandler(ProcessMessagesAsync, messageHandlerOptions);
        }

        static async Task ProcessMessagesAsync(Message message, CancellationToken token)
        {
            var messageBody = Encoding.UTF8.GetString(message.Body);

            var serviceBusMessage = JsonConvert.DeserializeObject<ServiceBusMessage>(messageBody);
            var users = JsonConvert.DeserializeObject<List<User>>(serviceBusMessage.Content);

            foreach (var user in users)
            {
                Console.WriteLine($"{user.Id}---{user.Name}");
            }
            //Console.WriteLine($"Received message:{serviceBusMessage.Content}");
            //Console.WriteLine($"Received message: UserInfo:{Encoding.UTF8.GetString(message.Body)}");

            await subscriptionClient.CompleteAsync(message.SystemProperties.LockToken);
        }

        static Task ExceptionReceivedHandler(ExceptionReceivedEventArgs exceptionReceivedEventArgs)
        {
            var exception = exceptionReceivedEventArgs.Exception;

            return Task.CompletedTask;
        }
    }
}
