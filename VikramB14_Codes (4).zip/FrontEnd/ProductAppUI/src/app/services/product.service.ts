import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from '../models/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  tempProductsToAddInBackdend?: Product[]=[];
  constructor(private httpClient: HttpClient) {
  }
  getAllProducts(): Observable<Array<Product>> {
    // API URL
    return this.httpClient.get<Array<Product>>('https://localhost:5005/api/Product/getAllProducts')
    //JSON URL
    // return this.httpClient.get<Array<Product>>('http://localhost:3000/products')
  }
  addProduct(productObj: Product): Observable<boolean> {
   this.tempProductsToAddInBackdend?.push(productObj);
    // debugger;
    // API URL
    return this.httpClient.post<boolean>('https://localhost:5005/api/Product/addProducts',  this.tempProductsToAddInBackdend)
    //JSON URL
    // return this.httpClient.post<Product>('http://localhost:3000/products', productObj)
  }
}
