import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RouterService {
  gotoProduct() {
    this.router.navigate(['display-product']);
  }

  constructor(private router: Router) { }

  gotoLogin() {
    this.router.navigate(['login']);
  }
  gotoRegister() {
    this.router.navigate(['register']);
  }

  setUserToken(userToken: any) {
    localStorage.setItem('TOKEN', userToken)
  }
  getUserToken() {

    return localStorage.getItem('TOKEN');
  }
  clearTokenStorage() {
    localStorage.clear();
  }
}
