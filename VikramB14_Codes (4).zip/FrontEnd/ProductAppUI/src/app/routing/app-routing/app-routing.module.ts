import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FooterComponent } from 'src/app/components/footer/footer.component';
import { RegisterComponent } from 'src/app/components/register/register.component';
import { LoginComponent } from 'src/app/components/login/login.component';
import { AddProductComponent } from 'src/app/products/add-product/add-product.component';
import { DisplayProductComponent } from 'src/app/products/display-product/display-product.component';
import { AuthGuard } from 'src/app/guard/auth.guard';
import { LogoutComponent } from 'src/app/components/logout/logout.component';

const routes: Routes = [
  { path: 'display-product', component: DisplayProductComponent, canActivate: [AuthGuard] },
  { path: 'footer', component: FooterComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'add-product', component: AddProductComponent },
  { path: 'logout', component: LogoutComponent },
  { path: '', component: LoginComponent, pathMatch: "full" }
]
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
