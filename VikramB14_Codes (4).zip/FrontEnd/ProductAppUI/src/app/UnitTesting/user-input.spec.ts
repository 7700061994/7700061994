import { userInput } from "./user-input";
describe('User Level Test cases', () => {
  it('User Input returns postive Correct of Pincode as Number', () => {

    let userPincode = 560001;
    let actulaResult = userInput(userPincode)
    expect(actulaResult).toBe(1);
  })


  it('User Input returns Negetive Correct of Pincode as Number', () => {
    let userPincode1 = -560001;
    let actulaResult1 = userInput(userPincode1)
    expect(actulaResult1).toBe(0)
  });
});