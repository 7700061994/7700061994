import { PincodeAvailability } from "./pincode-availability"

describe('Pincode availablity..............', () => {
  let pincodeAvailabity: PincodeAvailability;

  beforeEach(() => {
    pincodeAvailabity = new PincodeAvailability();
  });

  it('Pincode to Check GetallPinocdes returns Succcess!!', () => {
    let expectedPinocde = 560001;
    let actualPincodeNumbers = pincodeAvailabity.getAllPincodes()
    expect(actualPincodeNumbers).toContain(560001);
  });


  it('Test to Check Pincode returns reqired Pincode', () => {
    let expectedPinocdesCount = 560004;
    pincodeAvailabity.addPincode(560004);
    let actualPincodeResult = pincodeAvailabity.getAllPincodes();
    expect(actualPincodeResult).toContain(560004);
  })
});
