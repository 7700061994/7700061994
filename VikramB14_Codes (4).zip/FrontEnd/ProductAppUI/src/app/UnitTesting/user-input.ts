export function userInput(userPincode:number) {
    if(userPincode>0){

        return 1;
    }
    else{
        return 0;
    }
    
}
