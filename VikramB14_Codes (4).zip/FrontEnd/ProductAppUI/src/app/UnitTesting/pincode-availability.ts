export class PincodeAvailability {
    pincodes=[560001,56002,56003];

    getAllPincodes(){
          return this.pincodes;
    }

    addPincode(pincode:number){
        this.pincodes.push(pincode);
    }
}
