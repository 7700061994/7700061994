import { greetUser } from "./user-message";

describe('User Welcome Messages', () => {
  //1st test case
  it('Test to Check User GreetMessage Return Success', () => {
    let expectedResult = "Vikram";
    let userName = "Vikram"
    let actualResult = greetUser(userName);

    expect(actualResult).toContain(expectedResult);

  });

})