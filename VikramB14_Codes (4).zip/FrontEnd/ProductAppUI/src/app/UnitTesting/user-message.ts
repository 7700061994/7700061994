export function greetUser(userName: string) {

    return `Welcome::${userName}`
}