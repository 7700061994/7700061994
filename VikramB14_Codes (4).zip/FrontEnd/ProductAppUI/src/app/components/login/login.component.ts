import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserInfo } from 'src/app/models/user-info';
import { RouterService } from 'src/app/services/router/router.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userInfo: UserInfo;
  loginForm: FormGroup;
  constructor(private formBuilder: FormBuilder, private userService: UserService, private routerService: RouterService) {
    this.userInfo = new UserInfo();
    // this.loginForm = new FormGroup({});
    this.loginForm = formBuilder.group({
      name: ["", Validators.compose([Validators.required, Validators.minLength(6)])],
      password: ["", Validators.compose([Validators.required, Validators.minLength(2)])]
    });
  }

  ngOnInit(): void {

  }

  loginToSubmit(loginForm: FormGroup) {
    this.userInfo = loginForm.value;
    this.userService.login(this.userInfo).subscribe(res => {

      let jsonobject = JSON.stringify(res);
      let jsonToken = JSON.parse(jsonobject);
      this.routerService.setUserToken(jsonToken["tokken"]);
      this.routerService.gotoProduct();
    });

  }
}
