import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayProductHorizontalComponent } from './display-product-horizontal.component';

describe('DisplayProductHorizontalComponent', () => {
  let component: DisplayProductHorizontalComponent;
  let fixture: ComponentFixture<DisplayProductHorizontalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DisplayProductHorizontalComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayProductHorizontalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
