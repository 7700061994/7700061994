import { Component, Input, OnInit } from '@angular/core';
import { Product } from 'src/app/models/product';

@Component({
  selector: 'app-display-product-horizontal',
  templateUrl: './display-product-horizontal.component.html',
  styleUrls: ['./display-product-horizontal.component.css']
})
export class DisplayProductHorizontalComponent implements OnInit {
  @Input('parentData') public products?: Product[];
  constructor() {

  }

  ngOnInit(): void {
  }

}


