import { Component, Input, OnInit } from '@angular/core';
import { Product } from 'src/app/models/product';

@Component({
  selector: 'app-display-product-vertical',
  templateUrl: './display-product-vertical.component.html',
  styleUrls: ['./display-product-vertical.component.css']
})
export class DisplayProductVerticalComponent implements OnInit {
  @Input('parentData') public products?: Product[];
  constructor() { }

  ngOnInit(): void {
  }

}
