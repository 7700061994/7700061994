import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayProductVerticalComponent } from './display-product-vertical.component';

describe('DisplayProductVerticalComponent', () => {
  let component: DisplayProductVerticalComponent;
  let fixture: ComponentFixture<DisplayProductVerticalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DisplayProductVerticalComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayProductVerticalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
