import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/models/product';
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-display-product',
  templateUrl: './display-product.component.html',
  styleUrls: ['./display-product.component.css']
})
export class DisplayProductComponent implements OnInit {

  products?: Array<Product>
  constructor(private productService: ProductService) {

  }

  ngOnInit(): void {
    this.productService.getAllProducts().subscribe(res => {
      this.products = res;
    });
  }

}
