import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/models/product';
import { ProductService } from 'src/app/services/product.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  productObj: Product;
  constructor(private productService: ProductService) {

    this.productObj = new Product();
  }

  ngOnInit(): void {
  }

  addProduct() {
    // this.productService.addProduct(this.productObj).subscribe(res => {
    //   this.products?.push(res);
    // })
    //parseInt()
    this.productService.addProduct(this.productObj).subscribe({
      next: (res) => {
        if (res == true) {
          Swal.fire('Product added Successfully!!', 'Add Product', 'success')
        }
        //  this.tempProductsToAddInBackdend?.pop(); 
      },

      error: (e) => {
        Swal.fire('Product Registration failed', 'failed reg', 'error')
        // this.productErrorMessage = e.message;
        // console.error(e.message);
      },
    });

  }
}
