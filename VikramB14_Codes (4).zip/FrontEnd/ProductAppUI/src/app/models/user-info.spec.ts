import { UserInfo } from './user-info';

describe('UserInfo', () => {
  xit('should create an instance', () => {
    expect(new UserInfo()).toBeTruthy();
  });
});
