export class User {
    //id,name,password,isRegular,location
    id?: number;
    name?: string;
    password?: string;
    isRegular?: boolean;
    location?: string;
}
