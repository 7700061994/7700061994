import { User } from './user';

describe('User', () => {
  xit('should create an instance', () => {
    expect(new User()).toBeTruthy();
  });
});
