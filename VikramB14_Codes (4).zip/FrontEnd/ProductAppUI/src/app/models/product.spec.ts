import { Product } from './product';

describe('Product', () => {
  xit('should create an instance', () => {
    expect(new Product()).toBeTruthy();
  });
});
