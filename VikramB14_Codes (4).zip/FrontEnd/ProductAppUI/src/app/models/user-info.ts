export class UserInfo {
    //UserInfo name,password
    name?: string;
    password?: string;
}
