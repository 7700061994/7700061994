export class Product {
    id?: number;
    name?: string;
    rating?: any;
    isBlocked?: boolean;
}