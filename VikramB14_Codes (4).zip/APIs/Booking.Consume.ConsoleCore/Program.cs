﻿using System;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Text;
namespace Booking.Consume.ConsoleCore
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Fanout Consumer
            //Console.WriteLine("Hello World!");
            //ConnectionFactory connectionFactory = new ConnectionFactory();
            //connectionFactory.Uri = new Uri("amqp://vikramadmin:vikramadmin@localhost:5672");

            //var connection = connectionFactory.CreateConnection();
            //var channel = connection.CreateModel();
            //channel.QueueDeclare("ReceiveDataQueueFromExchange", true, false, false);
            //channel.QueueBind("ReceiveDataQueueFromExchange", "OrderBookingExchange", "");


            //var eventingBasicConsumer = new EventingBasicConsumer(channel);

            //eventingBasicConsumer.Received += (s, EventArgs) =>
            //{
            //    var resposeMessageFromSenderToReceiver = Encoding.UTF8.GetString(EventArgs.Body.ToArray());
            //    Console.WriteLine(resposeMessageFromSenderToReceiver);
            //};

            //channel.BasicConsume("ReceiveDataQueueFromExchange", true, eventingBasicConsumer);
            //Console.ReadLine();
            #endregion
            #region Direct
            Console.WriteLine("Hello World!");
            ConnectionFactory connectionFactory = new ConnectionFactory();
            connectionFactory.Uri = new Uri("amqp://vikramadmin:vikramadmin@localhost:5672");

            var connection = connectionFactory.CreateConnection();
            var channel = connection.CreateModel();
            channel.QueueDeclare("ReceiveDataQueueFromExchange", true, false, false);
            channel.QueueBind("ReceiveDataQueueFromExchange", "OrderBookingExchange", "Order.*");


            var eventingBasicConsumer = new EventingBasicConsumer(channel);

            eventingBasicConsumer.Received += (s, EventArgs) =>
            {
                var resposeMessageFromSenderToReceiver = Encoding.UTF8.GetString(EventArgs.Body.ToArray());
                Console.WriteLine(resposeMessageFromSenderToReceiver);
            };

            channel.BasicConsume("ReceiveDataQueueFromExchange", true, eventingBasicConsumer);
            Console.ReadLine();
            #endregion
        }
    }
}
