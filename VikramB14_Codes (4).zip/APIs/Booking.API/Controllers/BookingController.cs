﻿using Microsoft.AspNetCore.Mvc;
using RabbitMQ.Client;
using System;
using System.Text;
namespace Booking.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        [HttpPost]
        [Route("orderbooked")]
        public ActionResult BookOrder()
        {
            string textMessage = "sending data from Booking API";
            string routingKey = "Order.Booked";
            #region Fanout
            //ConnectionFactory connectionFactory = new ConnectionFactory();
            //connectionFactory.Uri = new Uri("amqp://vikramadmin:vikramadmin@localhost:5672");

            //var connection = connectionFactory.CreateConnection();
            //var channel = connection.CreateModel();

            //channel.ExchangeDeclare("OrderBookingExchange", ExchangeType.Fanout, true);
            //var messageInBytes = Encoding.UTF8.GetBytes(textMessage);

            //channel.BasicPublish("OrderBookingExchange", "", null, messageInBytes);

            //channel.Close();
            //connection.Close();
            //return Ok("Order Booked Successfully!!");
            #endregion
            SendMessageData(routingKey, textMessage);
            return Ok("Order Booked Successfully!!");
        }
        [HttpPost]
        [Route("ordercancelled")]
        public ActionResult CancelOrder()
        {
            string textMessage = "sending Order Cancel stataus from Booking API";
            string routingKey = "Order.Cancelled";
            SendMessageData(routingKey, textMessage);
            return Ok("Order Cancelled Successfully!!");
        }
        private void SendMessageData(string routingKey, string textMessage)
        {
            ConnectionFactory connectionFactory = new ConnectionFactory();
            connectionFactory.Uri = new Uri("amqp://vikramadmin:vikramadmin@localhost:5672");

            var connection = connectionFactory.CreateConnection();
            var channel = connection.CreateModel();

            channel.ExchangeDeclare("OrderBookingExchange", ExchangeType.Topic, true);
            var messageInBytes = Encoding.UTF8.GetBytes(textMessage);

            channel.BasicPublish("OrderBookingExchange", routingKey, null, messageInBytes);
            channel.Close();
            connection.Close();
        }
    }
}
