﻿using Moq;
using ProductApp.Exceptions;
using ProductApp.Models;
using ProductApp.Repository;
using ProductApp.Services;
using System.Collections.Generic;
using Xunit;

namespace ProductApp.Tests
{
    public class ProductServiceTest
    {
        IProductService _productService;
        public ProductServiceTest()
        {

        }

        [Fact]
        public void TestToCheckGetAllProductsReturnSuccess()
        {
            string expectedProductName = "MotoG10";
            var mockRepository = new Mock<IProductRepository>();
            mockRepository.Setup(p => p.GetAllProducts()).Returns(GetDummyDetails());
            _productService = new ProductService(mockRepository.Object);


            //Act
            var productDetails = _productService.GetAllProducts();
            var actualProductName = productDetails[0].Name;

            //Assert
            Assert.Equal(expectedProductName, actualProductName);

        }
        [Fact]
        public void TestToCheckGetProductByNameReturnException()
        {

            string productName = "sdfkashdifhdaskhf";
            string expectedExceptionMessage = $"Product::{productName} Not Found!!";
            Product product = null;
            var mockRepository = new Mock<IProductRepository>();
            mockRepository.Setup(p => p.GetProductByName(productName)).Returns(product);

            _productService = new ProductService(mockRepository.Object);
            var actualExceptionMessage = Assert.ThrowsAny<ProductNotFoundException>(() => _productService.GetProductByName(productName)).Message;

            Assert.Equal(expectedExceptionMessage, actualExceptionMessage);
        }
        private List<Product> GetDummyDetails()
        {
            return new List<Product> { new Product() { Name = "MotoG10", Rating = 9.1, IsBlocked = false } };
        }
    }

}
