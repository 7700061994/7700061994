﻿using ProductApp.Models;
using ProductApp.Repository;
using Xunit;

namespace ProductApp.Tests
{
    public class ProductRepositoryTest : IClassFixture<ProductDbFixture>
    {
        readonly IProductRepository _productRepository;
        public ProductRepositoryTest(ProductDbFixture productDbFixture)
        {
            _productRepository = new ProductRepository(productDbFixture._productDbContext);
        }

        [Fact]
        public void TestToCheckGetAllProductReturnSuccess()
        {
            //Initialize
            string expectedProductName = "LG";

            //act
            string actualProductName = _productRepository.GetAllProducts()[0].Name;


            //Assert
            Assert.Equal(expectedProductName, actualProductName);
        }
        //[Fact]
        //public void TestToCheckGetAllProductsReturnTotalCount()
        //{
        //    //Initialize
        //    int expectedPrdouctsCount = 1;

        //    //act
        //    int actualProductsCount = _productRepository.GetAllProducts().Count;


        //    //Assert
        //    Assert.Equal(expectedPrdouctsCount, actualProductsCount);
        //}
        [Fact]
        public void TestToCheckAddProductReturnSuccess()
        {
            string expectedProductName = "Thinkpad";
            Product[] products = new Product[1];
            products[0] = new Product() { Name = "Thinkpad", Rating = 9.7, IsBlocked = false };

            //Act
            _productRepository.AddProducts(products);
            string actualProductName = _productRepository.GetAllProducts()[1].Name;

            //Assert
            Assert.Equal(expectedProductName, actualProductName);
        }
        [Fact]
        public void TestToCheckGetProductByNameReturnNull()
        {
            //Act
            var actualProductExist=_productRepository.GetProductById(8463);
            Assert.Null(actualProductExist);
        }

    }
}
