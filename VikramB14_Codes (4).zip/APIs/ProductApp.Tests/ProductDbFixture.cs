﻿using Microsoft.EntityFrameworkCore;
using ProductApp.Context;
using ProductApp.Models;

namespace ProductApp.Tests
{
    public class ProductDbFixture
    {
        internal readonly ProductDbContext _productDbContext;
        public ProductDbFixture()
        {
            _productDbContext = new ProductDbContext(new DbContextOptionsBuilder<ProductDbContext>().UseInMemoryDatabase("ProductTestDb").Options);
            Product product = new Product()
            {
                Name = "LG",
                Rating = 9.8,
                IsBlocked = false
            };
            _productDbContext.Products.Add(product);
            _productDbContext.SaveChanges();
        }




    }
}
