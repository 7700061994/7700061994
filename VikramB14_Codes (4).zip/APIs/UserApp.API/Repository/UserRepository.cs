﻿using System.Collections.Generic;
using System.Linq;
using UserApp.API.Context;
using UserApp.API.Models;

namespace UserApp.API.Repository
{
    public class UserRepository : IUserRepository
    {
        readonly UserDbContext _userDbContext;
        public UserRepository(UserDbContext userDbContext)
        {
            _userDbContext = userDbContext;
        }

        public int AddUser(User user)
        {
            _userDbContext.Users.Add(user);
            return _userDbContext.SaveChanges();
        }

        public List<User> GetAllUsers()
        {
            return _userDbContext.Users.ToList();
        }

        public User Login(string userName, string password)
        {
            return _userDbContext.Users.Where(u => u.Name == userName && u.Password == password).FirstOrDefault();
        }

        public User GetUserByName(string userName)
        {
            return _userDbContext.Users.Where(u => u.Name == userName).FirstOrDefault();
        }
        public User GetUserById(int userId)
        {
            return _userDbContext.Users.Where(u => u.Id == userId).FirstOrDefault();
        }
    }
}
