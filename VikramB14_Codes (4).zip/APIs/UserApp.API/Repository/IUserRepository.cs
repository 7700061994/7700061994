﻿using System.Collections.Generic;
using UserApp.API.Models;

namespace UserApp.API.Repository
{
    public interface IUserRepository
    {
        List<User> GetAllUsers();
        int AddUser(User user);
        User Login(string userName, string password);
        User GetUserById(int userId);
        User GetUserByName(string userName);
    }
}
