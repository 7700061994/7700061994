﻿using Microsoft.AspNetCore.Mvc;
using UserApp.API.AOP;
using UserApp.API.Models;
using UserApp.API.Services;

namespace UserApp.API.Controllers
{
    [Route("v1/api/[controller]")]
    [ApiController]
    [ExceptionHandler]
    public class UserController : ControllerBase
    {
        readonly IUserService _userService;
        readonly ITokenGenerator _tokenGenerator;
        public UserController(IUserService userService, ITokenGenerator tokenGenerator)
        {
            _userService = userService;
            _tokenGenerator = tokenGenerator;
        }

        [HttpGet]
        [Route("getAllUsers")]
        public ActionResult GetAllUsers()
        {
            return Ok(_userService.GetAllUsers());
        }

        [HttpPost]
        [Route("register")]
        public ActionResult RegisterUser([FromBody] User user)
        {
            var addUserStatus = _userService.AddUser(user);
            return Ok(addUserStatus);
        }
        [HttpPost]
        [Route("login")]
        public ActionResult Login([FromBody] UserInfo userInfo)
        {
            User user = _userService.Login(userInfo);
            string token = _tokenGenerator.GenerateToken(user.Id, user.Name);
            return Ok(token);
        }
        [HttpGet]
        [Route("getUserById")]
        public ActionResult GetUserById(int userId)
        {
            return Ok($"{_userService.GetUserById(userId)}");
        }

        [HttpGet]
        [Route("getUserByName")]
        public ActionResult GetUserByName(string name)
        {
            return Ok($"{_userService.GetUserByName(name)}");
        }
    }
}
