# ConsoleApp
# TestApp
# LibrarayApp
# ASP.Net core API


# ASP.Net Core 
  * Weather Forecast API
  * Swashbuckle.ASPNetCore
  * Swagger
  * 5001
  * UserApp.API



# FlightBookingApp
  * UserAPI------------------5001
  * AirlineAPI---------------5003
  * BookingAPI---------------5005

# Migrations

 ```
 enable-migrations : The term 'enable-migrations' is not recognized as the name of a cmdlet, function, script file, or 
operable program. Check the spelling of the name, or if a path was included, verify that the path is correct and try 
again.
At line:1 char:1
+ enable-migrations
+ ~~~~~~~~~~~~~~~~~
    + CategoryInfo          : ObjectNotFound: (enable-migrations:String) [], CommandNotFoundException
    + FullyQualifiedErrorId : CommandNotFoundException
 
 ```

 `Note`: Microsoft.EntityFramworkCore.Tools
 
# UserController-------->Userpository--->UserDbContext

# UserController--->UserService--->Userpository--->UserDbContext

# Login---->Generate Token
# SRP
# SOC:Sepration of Conern
# Aspect Oriented Programming
# Continue with Layred Approach
* Protect your API
* user interface and classes
# How to start writing API Test Cases














