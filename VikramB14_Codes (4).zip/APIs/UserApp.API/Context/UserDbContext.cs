﻿using Microsoft.EntityFrameworkCore;
using UserApp.API.Models;

namespace UserApp.API.Context
{
    public class UserDbContext : DbContext
    {
        public UserDbContext(DbContextOptions<UserDbContext> options) : base(options)
        {
            Database.EnsureCreated();
        }

        //Tables
        public DbSet<User> Users { get; set; }

    }
}
