﻿using System;
namespace UserApp.API.Exceptions
{
    public class UserDetailsExistException : ApplicationException
    {
        public UserDetailsExistException()
        {

        }
        public UserDetailsExistException(string msg) : base(msg)
        {

        }
    }
}
