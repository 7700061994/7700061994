﻿using System;

namespace UserApp.API.Exceptions
{
    public class UserCredentailsInvalidException : ApplicationException
    {
        public UserCredentailsInvalidException()
        {

        }
        public UserCredentailsInvalidException(string message) : base(message)
        {

        }
    }
}
