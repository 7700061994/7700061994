﻿using System.Collections.Generic;
using UserApp.API.Models;

namespace UserApp.API.Services
{
    public interface IUserService
    {
        List<User> GetAllUsers();
        bool AddUser(User user);
        User Login(UserInfo userInfo);
        User GetUserById(int userId);
        User GetUserByName(string userName);
    }
}
