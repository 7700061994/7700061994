﻿namespace UserApp.API.Services
{
    public interface ITokenGenerator
    {
        string GenerateToken(int id, string name);
    }
}
