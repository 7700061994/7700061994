﻿using System.Collections.Generic;
using UserApp.API.Exceptions;
using UserApp.API.Models;
using UserApp.API.Repository;
namespace UserApp.API.Services
{
    public class UserService : IUserService
    {
        readonly IUserRepository _userRepository;
        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }
        public bool AddUser(User user)
        {
            var userByNameExist = _userRepository.GetUserByName(user.Name);
            if (userByNameExist == null)
            {
                var useraddResult = _userRepository.AddUser(user);
                if (useraddResult == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            else
            {
                throw new UserDetailsExistException($"{user.Name} and Other Details Exist!!");
            }

        }

        public List<User> GetAllUsers()
        {
            return _userRepository.GetAllUsers();
        }

        public User GetUserById(int userId)
        {
            return _userRepository.GetUserById(userId);
        }

        public User GetUserByName(string userName)
        {
            return _userRepository.GetUserByName(userName);
        }

        public User Login(UserInfo userInfo)
        {
            var userLoginResult = _userRepository.Login(userInfo.Name, userInfo.Password);
            if (userLoginResult != null)
            {
                return userLoginResult;
            }
            else
            {
                throw new UserCredentailsInvalidException($"User Details Invalid!!");
            }
        }
    }
}
