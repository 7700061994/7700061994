﻿using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
namespace UserApp.API.Services
{
    public class TokenGenerator : ITokenGenerator
    {
        public string GenerateToken(int id, string name)
        {
            var usersClaims = new[]
            {
                new Claim(JwtRegisteredClaimNames.UniqueName, id.ToString()),
                new Claim(JwtRegisteredClaimNames.Jti, new Guid().ToString())
            };
            string userSecretKey = "sakdhfkahdsklfklsdhhdskghlskk";
            var userSecretJeyInBytes = Encoding.UTF8.GetBytes(userSecretKey);
            var userSymmetricSecurityKey = new SymmetricSecurityKey(userSecretJeyInBytes);
            var userSigningCredentials = new SigningCredentials(userSymmetricSecurityKey, SecurityAlgorithms.HmacSha256);

            var userJwtSecurityToken = new JwtSecurityToken(
                issuer: "UserAPI",
                audience: "ProductApp",
                expires: DateTime.UtcNow.AddMinutes(5),
                signingCredentials: userSigningCredentials,
                claims: usersClaims
                );
            var userJwtToken = new { tokken = new JwtSecurityTokenHandler().WriteToken(userJwtSecurityToken) };
            return JsonConvert.SerializeObject(userJwtToken);
        }
    }
}
