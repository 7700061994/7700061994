﻿using Microsoft.AspNetCore.Mvc;
using Recommendation.API.Repository;
using System.Threading.Tasks;
namespace Recommendation.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RecommendationController : ControllerBase
    {
        readonly IRecommendRepository _recommendRepository;
        public RecommendationController(IRecommendRepository recommendRepository)
        {
            _recommendRepository = recommendRepository;
        }

        [HttpGet]
        [Route("productRecommendation")]
        public async Task<ActionResult> GetProductRecommendation()
        {
            var productResponse = await _recommendRepository.GetProductDetails();
            return new OkObjectResult(productResponse);

        }













    }
}
