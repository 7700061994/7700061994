﻿using System;
using System.Threading.Tasks;

namespace Recommendation.API.Repository
{
    public interface IRecommendRepository
    {
        Task<Object> GetProductDetails();
    }
}
