﻿using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace Recommendation.API.Repository
{
    public class RecommendRepository : IRecommendRepository
    {
        HttpClient httpClient;
        public async Task<Object> GetProductDetails()
        {
            using (httpClient = new HttpClient())
            {
                using (var appHttpClientRespose = await httpClient.GetAsync("https://localhost:5003/api/Product/getAllProducts"))
                {
                    var apiResponseResult = appHttpClientRespose.Content.ReadAsStringAsync().Result;
                    return apiResponseResult;
                }
            }
        }
    }
}
