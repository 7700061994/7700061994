﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace Recommendation.API.Models
{
    public class Product
    {
        #region 
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }
        public string Name { get; set; }
        public double Rating { get; set; }
        public bool IsBlocked { get; set; } = false;
        #endregion
    }
}
