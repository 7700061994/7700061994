﻿using Microsoft.EntityFrameworkCore;
using ProductApp.Context;
using ProductApp.Models;
using System.Collections.Generic;
using System.Linq;

namespace ProductApp.Repository
{
    public class ProductRepository : IProductRepository
    {
        readonly ProductDbContext _productDbContext;
        public ProductRepository(ProductDbContext productDbContext)
        {
            _productDbContext = productDbContext;
        }
        //public int AddProduct(Product product)
        //{
        //    var productList = _productDbContext.Products.AsQueryable();

        //    if (productList.Count() > 0)
        //    {
        //        product.Id = productList.Max(p => p.Id) + 1;
        //    }
        //    else
        //    {
        //        product.Id = 1;
        //    }

        //    _productDbContext.Products.Add(product);
        //    return _productDbContext.SaveChanges();

        //}

        //public bool AddProducts(List<Product> products)//5
        //{
        //    //10
        //    var productsList=_productDbContext.Products.AsQueryable();

        //    foreach(var productObj in products)
        //    {

        //        if (productsList.Count() > 0)
        //        {
        //            //11,12,13,14,15
        //            // 2,3,4,5
        //            //increment the id
        //            int updatedProductId=productsList.Max(p => p.Id) + 1;//11
        //            productObj.Id = updatedProductId;
        //            _productDbContext.Products.Add(productObj);
        //            _productDbContext.SaveChanges();
        //        }
        //        else
        //        {
        //            //for 5 starting valuee 
        //            //1 time it will execute
        //            productObj.Id = 1;
        //            _productDbContext.Products.Add(productObj);
        //            _productDbContext.SaveChanges();
        //        }
        //    }
        //    return true;
        //}

        public bool AddProducts(params Product[] products)//5
        {
            //10
            var productsList = _productDbContext.Products.AsQueryable();

            foreach (var productObj in products)
            {

                if (productsList.Count() > 0)
                {
                    //11,12,13,14,15
                    // 2,3,4,5
                    //increment the id
                    int updatedProductId = productsList.Max(p => p.Id) + 1;//11
                    productObj.Id = updatedProductId;
                    _productDbContext.Products.Add(productObj);
                    _productDbContext.SaveChanges();
                }
                else
                {
                    //for 5 starting valuee 
                    //1 time it will execute
                    productObj.Id = 1;
                    _productDbContext.Products.Add(productObj);
                    _productDbContext.SaveChanges();
                }
            }
            return true;
        }
        public int DeleteProduct(Product product)
        {
            var isProductRemoved = _productDbContext.Products.Remove(product);
            return _productDbContext.SaveChanges();

        }

        public List<Product> GetAllProducts()
        {
            return _productDbContext.Products.ToList();
        }

        public Product GetProductById(int id)
        {
            return _productDbContext.Products.Where(p => p.Id == id).FirstOrDefault();
        }

        public Product GetProductByName(string name)
        {
            return _productDbContext.Products.Where(p => p.Name == name).FirstOrDefault();
        }

        public Product UpdateProduct(int id, Product product)
        {
            _productDbContext.Entry<Product>(product).State = EntityState.Modified;
            _productDbContext.SaveChanges();
            return product;
        }
    }
}
