﻿using ProductApp.Models;
using System.Collections.Generic;

namespace ProductApp.Repository
{
    public interface IProductRepository
    {
        Product GetProductByName(string name);
        //int AddProduct(Product product);
        Product GetProductById(int id);
        int DeleteProduct(Product product);
        List<Product> GetAllProducts();
        Product UpdateProduct(int id, Product product);
        bool AddProducts(Product[] products);
    }
}
