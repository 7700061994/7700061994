﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Hosting;
using System;
using System.IO;
namespace ProductApp.AOP
{
    public class LoggingLogic : ActionFilterAttribute
    {
        DateTime StartTime;
        DateTime endTime;
        TimeSpan totalTime;
        readonly string logFileName = null;
        public LoggingLogic(IWebHostEnvironment environment)
        {
            logFileName = environment.ContentRootPath + @"/LoggerFiles/activity.txt";
        }
        public override void OnActionExecuting(ActionExecutingContext context)
        {

            StartTime = DateTime.Now;
            using (StreamWriter streamWriter = File.AppendText(logFileName))
            {
                var controllerBase = (ControllerBase)context.Controller;
                var controllerContext = controllerBase.ControllerContext;
                var controllerName = controllerContext.ActionDescriptor.ControllerName;
                var actionName = controllerContext.ActionDescriptor.ActionName;
                streamWriter.Write($"ControllerName:::{controllerName}\t ActionName:::{actionName}");
                streamWriter.Close();
            }


        }
        public override void OnActionExecuted(ActionExecutedContext context)
        {
            endTime = DateTime.Now;
            totalTime = endTime - StartTime;
            using (StreamWriter streamWriter = File.AppendText(logFileName))
            {
                streamWriter.Write($"Total time:::{totalTime.TotalSeconds}");
                streamWriter.WriteLine();
                streamWriter.Close();
            }
        }
    }
}
