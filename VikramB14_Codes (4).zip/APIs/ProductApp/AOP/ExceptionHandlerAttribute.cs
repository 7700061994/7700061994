﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using ProductApp.Exceptions;
namespace ProductApp.AOP
{
    public class ExceptionHandlerAttribute : ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            if (context.Exception.GetType() == typeof(ProductNotFoundException))
            {
                context.Result = new OkObjectResult(context.Exception.Message);
            }

        }
    }
}
