﻿using Microsoft.EntityFrameworkCore;
using ProductApp.Models;

namespace ProductApp.Context
{
    public class ProductDbContext : DbContext
    {
        public ProductDbContext(DbContextOptions<ProductDbContext> options) : base(options)
        {
            Database.EnsureCreated();
        }

        //Fluent API
        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    modelBuilder.Entity<Product>().HasKey("");
        //    modelBuilder.Entity<Product>().HasMany("").WithOne("").HasForeignKey();
        //}
        public DbSet<Product> Products { get; set; }
    }
}
