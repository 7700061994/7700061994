﻿using System;

namespace ProductApp.Exceptions
{
    public class ProductNotFoundException : ApplicationException
    {
        public ProductNotFoundException()
        {

        }
        public ProductNotFoundException(string message) : base(message)
        {

        }
    }
}
