﻿using System;
using System.Runtime.Serialization;

namespace ProductApp.Exceptions
{
    [Serializable]
    internal class ProductAlreadyExistException : ApplicationException
    {
        public ProductAlreadyExistException()
        {
        }

        public ProductAlreadyExistException(string message) : base(message)
        {
        }

        public ProductAlreadyExistException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected ProductAlreadyExistException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
