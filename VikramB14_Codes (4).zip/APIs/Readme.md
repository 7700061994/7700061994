# USerAPI
 * Admin
 * User



# USER API------------------------------UserManagementDb
  
  Applciation:
    * Register
    * Login------------------------->Token------------>sent to Frontend
           -----userId or userName



# Airline API---------------------------AirllineManagementDb
  Appliation:
    * AddAirline
    * CRUD


# Booking:





Angular|Web Application
        --------------------------

        Login---------------------------success---User
        ----------->Token------------>sent to Frontend
           -----userId or userName

        localstorage.SetItem('USERNAME',valueof userName)


        Search Flight Deatals--------->Booking
        -----------  --------------    -------------

        ---Book----   ----Book----    -----Book----

        this.userId=parseInt(localstorage.getItem('USERNAME'))
     BookingAPI---------------------------------------------BookingManagementDb
     HttpPost
     public ActionResult Booking([FromBody]Booking Booking)


     class Booking{
      
        public int Id
        public string UserName{get;set;}
        public long MobileNumber{get;set;}
        public strig EmailId{get;set;}

        List<Passenger>Passengers{get;set}
        [{},{}]
     }


     Bookings-----Table

     generatePNR
     Email Address


     -------------------------------------------------------
                                                BookingHistory

     -------------------------------------------------------

     this.localstroage.GetItem('USERNAME')

     if(empty){
          gotoLogin()
     }

     BookingAPI Backend Applcaition
     [HttpGet]
     getBookingsByEmailAddress(emailadderess)
     {

     }

     frontened:
     this.http.get(`localhost://5009/api/booking/getAllBookings/{emailadderess}`,headers:[Bearer:{this.localstorage.getItem('TOKEN'}])
     {

     }


     }











     }






     DB----->BookingAPI----->BookingManagementDb--------5009
                            Repository--->Insert------BookingManagementDb
             List<Booking> GetAllBookings()  

     RecommendationEngine<-------------BookingManagementDb
           * 5009
           * HttpClient---->List<Booking>

           * GetAllBookings()
             * StartLogic-------LINQ



     * List<Category>GetAllCategories(){

       }

       this.categoyselected="BNG";
       localstorage.setItem("USERCITY",this.categoyselected);



       # Validate Token
       # Don't share the database
       # communicate between start using Message Brokers
          * RabbitMQ
       # Azure Cloud
          * Azure Service Bus

   
       # relations
       

     //https://localhost:5003/api/Product/getAllProducts


         # Test Cases
           * Inmemory Databases
           * Moq
           * Repository
           * Service Level
           * Context
         # RabbitMQ

* RabbitMQ
  * [https://www.erlang.org/downloads](Erlang.org)
    `Note`: Select Windows Intaller 64 Bit
  * [https://www.rabbitmq.com/install-windows.html](RabbitMQ Installation)
    `Note`:rabbitmq-server-3.9.13.exe
  * RabbitMQ start-->Right Click-->Run as Administrator
  * RabbitMQ: 15672


  * Steps to Enable for RabbitMQ
  * Step1: Goto 
    C:\Program Files\RabbitMQ Server\rabbitmq_server-3.9.3\sbin
  * Step2 : Open command Prompt of the above location and type
    rabbitmq-plugins.bat enable rabbitmq_management
  * http://localhost:15672/#/
  * username:guest
    password:guest



  * RabbitMQ.Client----6.2.3
  * Producer-------E------>Consumer
    P--------------E------>C




    # Ocelot Gateway
     * [Ocelot Gateway](https://ocelot.readthedocs.io/en/latest/introduction/gettingstarted.html)
     * Gateway:https://localhost:5001
     * User API: https://localhost:5003
     * ProductAPI:https://localhost:5005
     * Booking API: https://localhost:5007
     * Recommendation API: https://localhost:5009
     * WeatherForecastAPI: https://localhost:5011




































