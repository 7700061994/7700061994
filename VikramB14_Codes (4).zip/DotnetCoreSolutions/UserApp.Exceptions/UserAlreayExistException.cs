﻿using System;

namespace UserApp.Exceptions
{
    public class UserAlreayExistException : ApplicationException
    {
        public UserAlreayExistException()
        {

        }
        public UserAlreayExistException(string msg) : base(msg)
        {

        }
    }
}
