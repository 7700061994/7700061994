﻿using Microsoft.AspNetCore.Mvc;
using UserApp.Entities.Models;
using UserApp.Reposiotry.Repository;

namespace UserApp.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        readonly IUserRepository _userRepository;
        public UserController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }
        [HttpGet]
        [Route("getAllUsers")]
        public ActionResult Get()
        {
            return Ok(_userRepository.GetAllUsers());
        }

        [HttpPost]
        [Route("register")]
        public ActionResult RegisterUser([FromBody]User user)
        {
            return Ok(_userRepository.AddUser(user));
        }
    }
}
