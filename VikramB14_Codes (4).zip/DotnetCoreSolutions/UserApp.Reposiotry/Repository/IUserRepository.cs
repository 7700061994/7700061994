﻿using System.Collections.Generic;
using UserApp.Entities.Models;

namespace UserApp.Reposiotry.Repository
{
    public interface IUserRepository
    {
        string AddUser(User user);
        List<User> GetAllUsers();
    }
}
