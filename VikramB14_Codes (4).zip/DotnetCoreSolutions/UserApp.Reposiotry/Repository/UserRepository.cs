﻿using System.Collections.Generic;
using UserApp.Entities.Models;
using UserApp.Exceptions;

namespace UserApp.Reposiotry.Repository
{
    public class UserRepository : IUserRepository
    {
        List<User> users;
        public UserRepository()
        {
            users = new List<User>();
        }
        public string AddUser(User user)
        {
            var userDetailsExist = GetUserByName(user.Name);
            if (userDetailsExist == null)
            {
                users.Add(user);
                return $"{user.Name} and Other Details Registered Succcessfully!!";
            }
            else
            {
                throw new UserAlreayExistException($"{user.Name} Exist!!");
            }
        }

        public List<User> GetAllUsers()
        {
            return users;
        }

        private User GetUserByName(string name)
        {
            return users.Find(u => u.Name == name);
        }
    }
}
