﻿using UserApp.Entities.Models;
using UserApp.Reposiotry.Repository;
using Xunit;

namespace UserApp.Tests
{
    public class UserRepositoryTest
    {
        UserRepository userRepository;
        public UserRepositoryTest()
        {
            userRepository = new UserRepository();
        }
        [Fact]
        public void GetAllUsersReturnSuccess()
        {
            //Initialization
            string expectedUserName = "User1";
            //call dev Code
            userRepository.AddUser(new User() { Id = 1, Name = "User1", Location = "Bengaluru" });
            userRepository.AddUser(new User() { Id = 2, Name = "User2", Location = "Bengaluru" });

            //Act
            string actualUserName = userRepository.GetAllUsers()[0].Name;


            //Assert
            Assert.Equal(expectedUserName, actualUserName);
        }
    }
}
