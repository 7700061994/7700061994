﻿using System;
using System.Collections.Generic;
using UserApp.Entities.Models;
using UserApp.Exceptions;
using UserApp.Reposiotry.Repository;

namespace UserApp
{
    class Program
    {
        static void Main(string[] args)
        {
            int counter = 0;
            User user = new User() { Id = 1, Name = "User1", Location = "Bengaluru" };
            IUserRepository userRepository = (IUserRepository)new UserRepository();

        addUser:
            try
            {
                userRepository.AddUser(user);
                counter = counter + 1;
            }
            catch (UserAlreayExistException uaex)
            {
                Console.WriteLine(uaex.Message);
                goto exit;
            }

            user = new User() { Id = 2, Name = "User1", Location = "Bengaluru" };
            if (counter == 2)
            {
                goto displayuser;
            }
            else
            {
                goto addUser;
            }


        displayuser:
            //GetAllUsers
            List<User> usersList = userRepository.GetAllUsers();
            foreach (var userObject in usersList)
            {
                Console.WriteLine(userObject.ToString());
            }

        exit:
            Console.WriteLine("End");
        }
    }
}
