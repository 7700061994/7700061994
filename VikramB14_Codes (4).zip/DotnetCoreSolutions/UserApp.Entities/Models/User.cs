﻿namespace UserApp.Entities.Models
{
    public class User
    {
        #region properties
        public int Id { get; set; }
        public string Name { get; set; }
        public string Location { get; set; }
        public bool IsRegular { get; set; } = true;
        #endregion

        public override string ToString()
        {
            return $"{Id}\t{Name}\t{Location}\t{IsRegular}";
        }

    }
}
