import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RouterService {
  DisplayUser() {
    this.router.navigate(['display-users']);
  }
  gotoDisplayBooking() {
    this.router.navigate(['display-booking']);
  }
  gotoAddBooking() {
    this.router.navigate(['add-booking']);
  }
  gotoAddAirline() {
    this.router.navigate(['add-airline']);
  }
  gotoBlockAirline() {
    this.router.navigate(['block-airline']);
  }
  gotoDisplayAirline() {
    this.router.navigate(['display-airline']);
  }
  gotoAirline() {
    this.router.navigate(['login']);
  }
gotoDashBoard(){
  this.router.navigate(['dashboard']);
}
  constructor(private router: Router) { }

  gotoLogin() {
    this.router.navigate(['login']);
  }
  gotoRegister() {
    this.router.navigate(['register']);
  }

  setUserToken(userToken: any) {
    localStorage.setItem('TOKEN', userToken)
  }
  getUserToken() {

    return localStorage.getItem('TOKEN');
  }
  clearTokenStorage() {
    localStorage.clear();
  }
}
