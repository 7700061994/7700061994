import { Injectable } from '@angular/core';

import { RouterService } from './router/router.service';

@Injectable({
  providedIn: 'root'
})
export class AirlineServiceService {

  constructor(private routerService:RouterService) { }
}
