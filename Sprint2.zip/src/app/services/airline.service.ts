import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Airlines } from '../models/airlines';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AirlineService {
  blockedAirline(airlineName: string):Observable<boolean> {
    

  return this.httpClient.put<boolean>('https://localhost:5007/api/Airline/BlockAirlineById',airlineName);
  }
  tempProductsToAddInBackdend?: Airlines[]=[];
  constructor(private httpClient: HttpClient) {
  }
  getAllAirlines(): Observable<Array<Airlines>> {
    // API URL
    return this.httpClient.get<Array<Airlines>>('https://localhost:5007/api/Airline/GetAllAirlines')
   
  }
  addAirline(productObj: Airlines): Observable<boolean> {
   this.tempProductsToAddInBackdend?.push(productObj);
    // debugger;
    // API URL
    return this.httpClient.post<boolean>('https://localhost:5007/api/Airline/addAirline',  this.tempProductsToAddInBackdend)
    //JSON URL
    
  }
}
