import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HeaderComponent } from './component/header/header.component';
import { FooterComponent } from './component/footer/footer.component';

import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatToolbarModule} from '@angular/material/toolbar';
import { NavComponent } from './component/nav/nav.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { RegisterComponent } from './component/register/register.component';
import { LoginComponent } from './component/login/login.component';
import { AppRoutingModule } from './routing/app-routing/app-routing.module';
import {MatCardModule} from '@angular/material/card';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatInputModule} from '@angular/material/input';
import { LogoutComponent } from './component/logout/logout.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { DisplayAirlineComponent } from './airline/display-airline/display-airline.component';
import { AddAirlineComponent } from './airline/add-airline/add-airline.component';
import {MatRadioModule} from '@angular/material/radio';
import { DisplayAirlineVerticleComponent } from './airline/display-airline/display-airline-verticle/display-airline-verticle.component';
import { DashboardComponent } from './dashboard/dashboard/dashboard.component';
import { AddBookingComponent } from './dashboard/booking/add-booking/add-booking.component';
import { DisplayBookingComponent } from './dashboard/booking/display-booking/display-booking.component';
import { DisplayUsersComponent } from './dashboard/user/display-users/display-users.component';
import { BlockAirlineComponent } from './airline/block-airline/block-airline.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    NavComponent,
    RegisterComponent,
    LoginComponent,
    LogoutComponent,
    DisplayAirlineComponent,
    AddAirlineComponent,
    DisplayAirlineVerticleComponent,
    DashboardComponent,
    AddBookingComponent,
    DisplayBookingComponent,
    DisplayUsersComponent,
    BlockAirlineComponent,
   
  ],
  imports: [
    BrowserModule,HttpClientModule, BrowserAnimationsModule,MatToolbarModule, LayoutModule,
     MatButtonModule, MatSidenavModule, MatIconModule, MatListModule,
     AppRoutingModule,MatCardModule,MatExpansionModule,MatInputModule,FormsModule,
     ReactiveFormsModule,
     MatFormFieldModule,MatRadioModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
