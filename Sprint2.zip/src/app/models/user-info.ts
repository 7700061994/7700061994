export class UserInfo {

    name?: string;
    password?: string;
}
