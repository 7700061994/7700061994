import { FlightBooking } from './flight-booking';

describe('FlightBooking', () => {
  it('should create an instance', () => {
    expect(new FlightBooking()).toBeTruthy();
  });
});
