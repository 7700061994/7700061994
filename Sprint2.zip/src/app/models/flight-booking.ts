export class FlightBooking {
    Id ?:number;
    pnrNo ?:number;
    name?:string; 
    email?:string;
    
    gender?:string;
    fromPlace?:string;
    toPlace?: string;
    bookingDate?:string;
    bookingTime?:string;

    isCancel?:boolean;
}
