export class Airlines {
    id?:number;
    airlineName?:string;
    fromPlace?:string;
    toPlace?:string;
    ticketCost?:string;
    bussinessSeats?:string;
    nonBussinessSeats?:string;
    isBlocked?:boolean;
    instrumentType?:string;
   
}
