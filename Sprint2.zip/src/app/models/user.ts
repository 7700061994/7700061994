export class User {

    id?: number;
    name?: string;
    password?: string;
    isDeleted?: boolean;
    role?: string;
}
