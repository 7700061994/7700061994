import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-display-booking',
  templateUrl: './display-booking.component.html',
  styleUrls: ['./display-booking.component.css']
})
export class DisplayBookingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
