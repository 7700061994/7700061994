import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FooterComponent } from 'src/app/component/footer/footer.component';
import { RegisterComponent } from 'src/app/component/register/register.component';
import { LoginComponent } from 'src/app/component/login/login.component';
import { AddAirlineComponent } from 'src/app/airline/add-airline/add-airline.component';
import { DisplayAirlineComponent } from 'src/app/airline/display-airline/display-airline.component';

import { AuthGuard } from 'src/app/guard/auth.guard';
import { LogoutComponent } from 'src/app/component/logout/logout.component';
import { DashboardComponent } from 'src/app/dashboard/dashboard/dashboard.component';
import { AddBookingComponent } from 'src/app/dashboard/booking/add-booking/add-booking.component';
import { DisplayBookingComponent } from 'src/app/dashboard/booking/display-booking/display-booking.component';
import { BlockAirlineComponent } from 'src/app/airline/block-airline/block-airline.component';
import { DisplayUsersComponent } from 'src/app/dashboard/user/display-users/display-users.component';


const routes:Routes=[
  {path:'dashboard',component:DashboardComponent,canActivate:[AuthGuard]},
  {path:'register',component:RegisterComponent},
  {path:'login',component:LoginComponent},
  { path: 'add-airline', component: AddAirlineComponent },
  { path: 'display-airline', component: DisplayAirlineComponent },
  { path: 'block-airline', component: BlockAirlineComponent },
  { path: 'add-booking', component: AddBookingComponent },
  { path: 'display-booking', component: DisplayBookingComponent },
  { path: 'display-user', component: DisplayUsersComponent },
  { path: 'logout', component: LogoutComponent },
  { path: '', component: LoginComponent, pathMatch: "full" }
]
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],exports:[RouterModule]
})
export class AppRoutingModule { }
