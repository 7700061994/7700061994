import { Component, OnInit } from '@angular/core';
import { AirlineService } from 'src/app/services/airline.service';
import { Airlines } from 'src/app/models/airlines';
import Swal from 'sweetalert2';
import { RouterService } from 'src/app/services/router/router.service';

@Component({
  selector: 'app-block-airline',
  templateUrl: './block-airline.component.html',
  styleUrls: ['./block-airline.component.css']
})
export class BlockAirlineComponent implements OnInit {
airlineName:string='';
  constructor(private airlineService:AirlineService,private routerService:RouterService) {
    
   }

  ngOnInit(): void {
  }
  blockAirline(){
      this.airlineService.blockedAirline(this.airlineName).subscribe(res=>{
        if (res = true) {
          Swal.fire('Airline Blocked Successfully!!', 'Block Airline', 'success')
          this.routerService.gotoDisplayAirline();
        }
      });

  
  }

}
