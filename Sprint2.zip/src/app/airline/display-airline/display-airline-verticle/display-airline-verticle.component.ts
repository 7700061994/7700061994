import { Component, Input, OnInit } from '@angular/core';
import { Airlines } from 'src/app/models/airlines';

@Component({
  selector: 'app-display-airline-verticle',
  templateUrl: './display-airline-verticle.component.html',
  styleUrls: ['./display-airline-verticle.component.css']
})
export class DisplayAirlineVerticleComponent implements OnInit {
  @Input('parentData') public airlines?: Array<Airlines>;
  constructor() { }

  ngOnInit(): void {
  }

}
