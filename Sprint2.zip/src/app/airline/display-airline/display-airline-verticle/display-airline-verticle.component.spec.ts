import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayAirlineVerticleComponent } from './display-airline-verticle.component';

describe('DisplayAirlineVerticleComponent', () => {
  let component: DisplayAirlineVerticleComponent;
  let fixture: ComponentFixture<DisplayAirlineVerticleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisplayAirlineVerticleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayAirlineVerticleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
