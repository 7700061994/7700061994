import { Component, OnInit } from '@angular/core';
import { Airlines } from 'src/app/models/airlines';
import { AirlineService } from 'src/app/services/airline.service';
import { RouterService } from 'src/app/services/router/router.service';
@Component({
  selector: 'app-display-airline',
  templateUrl: './display-airline.component.html',
  styleUrls: ['./display-airline.component.css']
})
export class DisplayAirlineComponent implements OnInit {
   airlines?: Array<Airlines>
  constructor(private airlineService: AirlineService,private routerService:RouterService) {

  }

  ngOnInit(): void {
    this.airlineService.getAllAirlines().subscribe(res => {
      this.airlines = res;
    });
  }
  AddAirline(){
    this.routerService.gotoAddAirline();
  }

}
