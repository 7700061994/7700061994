import { Component, OnInit } from '@angular/core';
import { Airlines } from 'src/app/models/airlines';
import Swal from 'sweetalert2';
import { AirlineService } from 'src/app/services/airline.service';
import { RouterService } from 'src/app/services/router/router.service';
@Component({
  selector: 'app-add-airline',
  templateUrl: './add-airline.component.html',
  styleUrls: ['./add-airline.component.css']
})
export class AddAirlineComponent implements OnInit {

  airlineObj: Airlines;
  constructor(private airlineService: AirlineService, private routerService:RouterService) {

    this.airlineObj = new Airlines();
  }


  ngOnInit(): void {
  }
  addairline() {
    
    this.airlineService.addAirline(this.airlineObj).subscribe({
      next: (res) => {
        if (res == true) {
          Swal.fire('Airline added Successfully!!', 'Add Airline', 'success')
          this.routerService.gotoDisplayAirline();
        }
       
      },

      error: (e) => {
        Swal.fire('Airline Registration failed', 'failed reg', 'error')
        // this.productErrorMessage = e.message;
        // console.error(e.message);
      },
    });

  }
}
