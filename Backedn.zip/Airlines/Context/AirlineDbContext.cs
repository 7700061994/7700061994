﻿using Airlines.Models;
using Microsoft.EntityFrameworkCore;
namespace Airlines.Context
{
    public class AirlineDbContext : DbContext
    {

        public AirlineDbContext(DbContextOptions<AirlineDbContext> options) : base(options)
        {
            Database.EnsureCreated();
           
        }

        public DbSet<Airline> Airlines { get; set; }
        public DbSet<AirlineInventory> AirlineInventories { get; set; }
    }
}
