﻿using Airlines.AOP;
using Airlines.Models;
using Airlines.Services;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Airlines.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Exceptionhandler]
    public class AirlineController : ControllerBase
    {
        readonly IAirlineService _airlineService;

        public AirlineController(IAirlineService airlineService)
        {
            _airlineService = airlineService;
        }
       
        [HttpPost]
        [Route("addAirline")]

        public ActionResult Airlineregister([FromBody] Airline[] airline)
        {
            bool isAirlineRegister = _airlineService.AirlineRegister(airline);
            return Ok(isAirlineRegister);
        }

        [HttpPost]
        [Route("addInventory")]

        public ActionResult AddInventory([FromBody] AirlineInventory[] airlineInventories)
        {
            bool isInventoryAdd = _airlineService.AddInventory(airlineInventories);
            return Ok(isInventoryAdd);
        }

        [HttpGet]
        [Route("getAllAirlines")]
        public ActionResult GetAllAirlines()
        {
            List<Airline> airlines = _airlineService.GetAllAirlines();
            return Ok(airlines);
        }
        [HttpGet]
        [Route("getAllInventoryDetails")]
        public ActionResult GetAllInventoryDetails()
        {
            List<AirlineInventory> airlineInventories = _airlineService.GetAllInventoryDetails();
            return Ok(airlineInventories);
        }
        [HttpDelete]
        [Route("deleteAirlinebyName")]

        public ActionResult DeleteAirlineByName(string name)
        {
            bool airlineDeleteStatus = _airlineService.DeleteAirlineByName(name);
            return Ok(airlineDeleteStatus);

        }
        [HttpGet]
        [Route("blockAirlineByName/{name}")]
        public ActionResult BlockAirlineByName(string name)
        {
            bool airlineDeleteStatus = _airlineService.BlockAirlineByName(name);
            return Ok(airlineDeleteStatus);

        }
        [HttpGet]
        [Route("unBlockAirlineByName/{name}")]
        public ActionResult UnBlockAirlineByName(string name)
        {
            bool airlineDeleteStatus = _airlineService.UnBlockAirlineByName(name);
            return Ok(airlineDeleteStatus);

        }

        [HttpGet]
        [Route("getAirlinesBySearch")]
        public ActionResult getAirlinesBySearch(string fromPlace, string toPlace)
        {
            List<AirlineInventory> airlineInventories = _airlineService.getAirlinesBySearch(fromPlace,toPlace);
            return Ok(airlineInventories);

        }



    }
}
