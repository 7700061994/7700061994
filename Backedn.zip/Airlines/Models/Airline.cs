﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Airlines.Models
{
    public class Airline
    {
        #region Properties
        [JsonIgnore]
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }
        public string AirlineName { get; set; }

        public string AirlineAddress { get; set; }
        public string ContactNo { get; set; }
       public bool IsBlocked { get; set; } = false;

        #endregion
    }
}
