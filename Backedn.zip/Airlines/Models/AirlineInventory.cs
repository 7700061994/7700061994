﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Airlines.Models
{
    public class AirlineInventory
    {
        #region Properties
        [JsonIgnore]
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }
        public string AirlineName { get; set; }
        public string FlightNumber { get; set; }
        public string FromPlace { get; set; }
        public string ToPlace { get; set; }
        public int BussinessSeats { get; set; }
        public int BussinessSeatPrice { get; set; }
        public int NonBussinessSeats { get; set; }
        public int NonBussinessSeatPrice { get; set; }
        public int NoOfRow { get; set; }
        public string Meal { get; set; }
        public string ScheduledDays { get; set; }
        public string InstrumentUsed { get; set; }
        public bool isBlocked { get; set; } = false;

        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public Airline Airline { get; set; }



        #endregion

    }
}
