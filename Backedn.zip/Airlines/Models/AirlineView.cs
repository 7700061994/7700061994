﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Airlines.Models
{
    public class AirlineView
    {
        public string airLineName { get; set; }
        public IFormFile formFile { get; set; }
    }
}
