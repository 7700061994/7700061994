﻿
using Airlines.Models;
using System.Collections.Generic;

namespace Airlines.Repository
{
    public interface IAirlineRepository
    {



        Airline GetAirlineByName(string name);
        int DeleteAirline(Airline airline);
        bool AirlineRegister(Airline[] airlines);
        List<Airline> GetAirlines();
        int BlockAirlineByName(string name, Airline airline);
        int UnBlockAirlineByName(string name,Airline airline);
        Airline GetAirlineById(int id);
        bool AddInventory(AirlineInventory[] airlineInventories);
        List<AirlineInventory> GetAllInventoryDetails();
        List<AirlineInventory> getAirlinesBySearch(string fromPlace, string toPlace);
    }
}
