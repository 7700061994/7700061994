﻿using Airlines.Context;
using Airlines.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace Airlines.Repository
{
    public class AirlineRepository : IAirlineRepository
    {
        readonly AirlineDbContext _airlineDbContext;
        public AirlineRepository(AirlineDbContext airlineDbContext)
        {
            _airlineDbContext = airlineDbContext;
        }
        public bool AddInventory(AirlineInventory[] airlineInventories)
        {
            var inventoryAdd = _airlineDbContext.AirlineInventories.AsQueryable();

            foreach (var InventoryObj in airlineInventories)
            {
                if (inventoryAdd.Count() > 0)
                {
                    int Id = inventoryAdd.Max(a => a.Id) + 1;
                    InventoryObj.Id = Id;

                    _airlineDbContext.AirlineInventories.Add(InventoryObj);
                    _airlineDbContext.SaveChanges();

                }
                else
                {
                    InventoryObj.Id = 1;

                    _airlineDbContext.AirlineInventories.Add(InventoryObj);
                    _airlineDbContext.SaveChanges();

                }
            }
            return true;
        }
        public bool AirlineRegister(Airline[] airlines)
        {
            var registerAirline = _airlineDbContext.Airlines.AsQueryable();

            foreach (var airlineObj in airlines)
            {
                if (registerAirline.Count() > 0)
                {
                    int Id = registerAirline.Max(a => a.Id) + 1;
                    airlineObj.Id = Id;
                   
                    _airlineDbContext.Airlines.Add(airlineObj);
                    _airlineDbContext.SaveChanges();

                }
                else
                {
                    airlineObj.Id = 1;

                    _airlineDbContext.Airlines.Add(airlineObj);
                    _airlineDbContext.SaveChanges();

                }
            }
            return true;
        }

        public int BlockAirlineByName(string name, Airline airline)
        {
            
                airline.IsBlocked = true;

                _airlineDbContext.Entry<Airline>(airline).State = EntityState.Modified;
                return _airlineDbContext.SaveChanges();
            
            
        }
        public int UnBlockAirlineByName(string name, Airline airline)
        {
            airline.IsBlocked = false;

            _airlineDbContext.Entry<Airline>(airline).State = EntityState.Modified;
            return _airlineDbContext.SaveChanges();

        }
        public int DeleteAirline(Airline airline)
        {
            var isairlineCanceled = _airlineDbContext.Airlines.Remove(airline);
            return _airlineDbContext.SaveChanges();
        }




        public Airline GetAirlineByName(string name)
        {
           
            return _airlineDbContext.Airlines.Where(a => a.AirlineName==name).FirstOrDefault();
        }

        public Airline GetAirlineById(int id)
        {
            return _airlineDbContext.Airlines.Where(a => a.Id == id).FirstOrDefault();
        }

        public List<Airline> GetAirlines()
        {
            return _airlineDbContext.Airlines.ToList();
        }

        public List<AirlineInventory> GetAllInventoryDetails()
        {
            return _airlineDbContext.AirlineInventories.ToList();
        }

        public List<AirlineInventory> getAirlinesBySearch(string fromPlace, string toPlace)
        {
            return _airlineDbContext.AirlineInventories.Where(i=>(i.FromPlace==fromPlace) && (i.ToPlace==toPlace) ).ToList();
        }
    }
}
