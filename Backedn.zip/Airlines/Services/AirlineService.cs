﻿using Airlines.Exceptions;
using Airlines.Models;
using Airlines.Repository;
using System.Collections.Generic;

namespace Airlines.Services
{
    public class AirlineService : IAirlineService
    {
        readonly IAirlineRepository _airlineRepository;

        public AirlineService(IAirlineRepository airlineRepository)
        {
            _airlineRepository = airlineRepository;
        }

        public bool AddInventory(AirlineInventory[] airlineInventories)
        {

            return _airlineRepository.AddInventory(airlineInventories);
        }

        public bool AirlineRegister(Airline[] airline)
        {
            return _airlineRepository.AirlineRegister(airline);
        }
        public bool UnBlockAirlineByName(string name)
        {


            var airlines = _airlineRepository.GetAirlineByName(name);
            if (airlines != null)
            {
                int airlineBlockStatus = _airlineRepository.UnBlockAirlineByName(name, airlines);
                if (airlineBlockStatus == 1)
                    return true;
                else
                    return false;

            }
            else
            {
                throw new AirlineNotFoundException($"Airline::{name} Not Found");
            }
        }
        public bool BlockAirlineByName(string name)
        {
            

            var airlines = _airlineRepository.GetAirlineByName(name);
            if (airlines != null)
            {
                int airlineBlockStatus = _airlineRepository.BlockAirlineByName(name,airlines);
                if (airlineBlockStatus == 1)
                    return true;
                else
                    return false;

            }
            else
            {
                throw new AirlineNotFoundException($"Airline::{name} Not Found");
            }
        }

        public bool DeleteAirlineByName(string name)
        {
            Airline airline = _airlineRepository.GetAirlineByName(name);
            if (airline != null)
            {
                int airlineDeleteStatus = _airlineRepository.DeleteAirline(airline);
                if (airlineDeleteStatus == 1)
                    return true;
                else
                    return false;

            }
            else
            {
                throw new AirlineNotFoundException($"Airline::{name} Not Found");
            }
        }



        public List<Airline> GetAllAirlines()
        {
            return _airlineRepository.GetAirlines();
        }

        public List<AirlineInventory> GetAllInventoryDetails()
        {
            return _airlineRepository.GetAllInventoryDetails();
        }

        public List<AirlineInventory> getAirlinesBySearch(string fromPlace, string toPlace)
        {
            return _airlineRepository.getAirlinesBySearch(fromPlace, toPlace);

        }
    }
}
