﻿using Airlines.Models;
using System.Collections.Generic;


namespace Airlines.Services
{
    public interface IAirlineService
    {
        bool AirlineRegister(Airline[] airline);
        List<Airline> GetAllAirlines();
        bool DeleteAirlineByName(string name);
        bool BlockAirlineByName(string name);
        bool UnBlockAirlineByName(string name);
        bool AddInventory(AirlineInventory[] airlineInventories);
        List<AirlineInventory> GetAllInventoryDetails();
        List<AirlineInventory> getAirlinesBySearch(string fromPlace, string toPlace);
    }
}
