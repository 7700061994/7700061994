﻿
using FlightBooking.Models;
using System.Collections.Generic;

namespace FlightBooking.Repository
{
    public interface IBookingRepository
    {
        List<FlightBook> GetBookingByEmailId(string Email);

        List<FlightBook> getBookingHistoryByUserId(int userId);

        int deleteBookingByPnrNo(FlightBook flightBook);
        bool FlightBooking(FlightBook[] flightBooks);
        FlightBook CancelBookingBefore24Hour(int pnrNo, FlightBook flightBooks);
        FlightBook getBookingHistoryByPnr(int pnrNo);
        List<FlightBook> getBookingHistoryByPnrNo(int pnrNo);
      
    }
}
