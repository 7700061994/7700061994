﻿using FlightBooking.Context;
using FlightBooking.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace FlightBooking.Repository
{
    public class BookingRepository : IBookingRepository
    {
        readonly BookingDbContext _bookingDbContext;
        public BookingRepository(BookingDbContext bookingDbContext)
        {
            _bookingDbContext = bookingDbContext;
        }

        public FlightBook CancelBookingBefore24Hour(int pnrNo, FlightBook flightBooks)
        {
            _bookingDbContext.Add(flightBooks.IsCancel = true);
            _bookingDbContext.Entry<FlightBook>(flightBooks).State = EntityState.Modified;
            _bookingDbContext.SaveChanges();
            return flightBooks;
        }

        public int deleteBookingByPnrNo(FlightBook flightBook)
        {
            var isBookingCanceled = _bookingDbContext.FlightBookings.Remove(flightBook);
            return _bookingDbContext.SaveChanges();
        }

        public bool FlightBooking(FlightBook[] flightBooks)
        {
            var Bookings = _bookingDbContext.FlightBookings.AsQueryable();

            foreach (var bookingObj in flightBooks)
            {
                if (Bookings.Count() > 0)
                {
                    int Id = Bookings.Max(p => p.Id) + 1;
                    bookingObj.Id = Id;
                    int UpdateBookingId = Bookings.Max(p => p.PnrNo) + 1;
                    bookingObj.PnrNo = UpdateBookingId;
                    _bookingDbContext.FlightBookings.Add(bookingObj);
                    _bookingDbContext.SaveChanges();

                }
                else
                {
                    bookingObj.Id = 1;
                    bookingObj.PnrNo = 2022001;
                    _bookingDbContext.FlightBookings.Add(bookingObj);
                    _bookingDbContext.SaveChanges();

                }
            }
            return true;

        }

        public List<FlightBook> getBookingHistoryByUserId(int userId)
        {
            return _bookingDbContext.FlightBookings.Where(b => b.UserId == userId).ToList();
        }
        public FlightBook getBookingHistoryByPnr(int pnrNo)
        {
            return _bookingDbContext.FlightBookings.Where(b => b.PnrNo == pnrNo).FirstOrDefault();
        }


       public List<FlightBook> GetBookingByEmailId(string Email)
        {
            return _bookingDbContext.FlightBookings.Where(p => p.emailId == Email).ToList();
        }

        public List<FlightBook> getBookingHistoryByPnrNo(int pnrNo)
        {
            return _bookingDbContext.FlightBookings.Where(b => b.PnrNo == pnrNo).ToList();

        }
    }
}
