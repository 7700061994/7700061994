﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightBooking.Exceptions
{
    public class BookingTimeExceededException : ApplicationException
    { 
        public BookingTimeExceededException()
        {

        }
        
        public  BookingTimeExceededException(string message):base (message)
        {
        }
    }
   
}
