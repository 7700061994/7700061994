﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace FlightBooking.Models
{
    public class FlightBook
    {
        #region Properties
        [JsonIgnore]
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }
        public int PnrNo { get; set; }
        public int UserId { get; set; }
        public string FlightNo { get; set; }
        public bool IsCancel { get; set; }
        public string emailId { get; set; }
   public string fromPlace { get; set; }
   public string toPlace { get; set; }
   public string startDate { get; set; }
   public string endDate { get; set; }
        public DateTime BookingDate { get; set; } = System.DateTime.Now;


        #endregion
    }
}
