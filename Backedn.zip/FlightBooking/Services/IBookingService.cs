﻿using FlightBooking.Models;
using System.Collections.Generic;


namespace FlightBooking.Services
{
    public interface IBookingService
    {
        List<FlightBook> GetbookingByEmailId(string Emailid);

        bool deleteBookingByPnrNo(int BookingId);

        List<FlightBook> getBookingHistoryByUserId(int userId);
        bool FlightBooking(FlightBook[] flightBooks);
        FlightBook CancelBookingBefore24Hour(int pnrNo, FlightBook flightBooks);
        List<FlightBook> getBookingHistoryByPnrNo(int pnrNo);
    }
}
