﻿using FlightBooking.AOP;
using FlightBooking.Models;
using FlightBooking.Services;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;


namespace FlightBooking.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Exceptionhandler]
    public class BookingController : ControllerBase
    {
        readonly IBookingService _bookingService;

        public BookingController(IBookingService bookingService)
        {
            _bookingService = bookingService;
        }

        [HttpPost]
        [Route("addBooking")]
          public ActionResult FlightBooking([FromBody] FlightBook[] flightBooks)
        {
            bool bookingStatus = _bookingService.FlightBooking(flightBooks);
            return Ok(bookingStatus);
        }

        [HttpGet]
        [Route("getBookingHistoryByUserId/{Id:int}")]
        public ActionResult getBookingHistoryByUserId(int Id)
        {
            List<FlightBook> flightBook = _bookingService.getBookingHistoryByUserId(Id);
            return Ok(flightBook);
        }
        [HttpGet]
        [Route("getBookingHistoryByPnrNo/{pnrNo:int}")]
        public ActionResult getBookingHistoryByPnrNo(int pnrNo)
        {
            List<FlightBook> flightBook = _bookingService.getBookingHistoryByPnrNo(pnrNo);
            return Ok(flightBook);
        }
        [HttpDelete]
        [Route("deleteBookingByPnrNo/{pnrNo}")]

        public ActionResult deleteBookingByPnrNo(int pnrNo)
        {
            bool bookingCancelStatus = _bookingService.deleteBookingByPnrNo(pnrNo);
            return Ok(bookingCancelStatus);
        }
        [HttpGet]
        [Route("getBookingHistoryByEmailid/{EmailId}")]
        public ActionResult GetBookingByEmailId(string EmailId)
        {
            List<FlightBook> flightBook = _bookingService.GetbookingByEmailId(EmailId);
            return Ok(flightBook);
        }
        [HttpPut]
        [Route("cancelBookingBefore24Hour")]

        public ActionResult CancelBookingBefore24Hour(int pnrNo,[FromBody] FlightBook flightBooks)
        {
            FlightBook flightBook = _bookingService.CancelBookingBefore24Hour(pnrNo, flightBooks);
            return Ok(flightBook);
        }
       
    }
}
