﻿using Airlines.Exceptions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Airlines.AOP
{
    public class ExceptionhandlerAttribute : ExceptionFilterAttribute

    {
        public override void OnException(ExceptionContext context)
        {
            if (context.Exception.GetType() == typeof(AirlineNotFoundException))
            {
                context.Result = new OkObjectResult(context.Exception.Message);
            }
        }
    }
}
