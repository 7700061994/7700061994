﻿
using Airlines.Models;
using System.Collections.Generic;

namespace Airlines.Repository
{
    public interface IAirlineRepository
    {



        Airline GetAirlineByName(string name);
        int DeleteAirline(Airline airline);
        bool AirlineRegister(Airline[] airlines);
        List<Airline> GetAirlines();
        int BlockAirline(int id, Airline airline);
        Airline GetAirlineById(int id);
    }
}
