﻿using Airlines.Exceptions;
using Airlines.Models;
using Airlines.Repository;
using System.Collections.Generic;

namespace Airlines.Services
{
    public class AirlineService : IAirlineService
    {
        readonly IAirlineRepository _airlineRepository;

        public AirlineService(IAirlineRepository airlineRepository)
        {
            _airlineRepository = airlineRepository;
        }

        public bool AirlineRegister(Airline[] airline)
        {
            return _airlineRepository.AirlineRegister(airline);
        }

        public bool BlockAirlineByName(int id)
        {
            

            var airlines = _airlineRepository.GetAirlineById(id);
            if (airlines != null)
            {
                int airlineBlockStatus = _airlineRepository.BlockAirline(id,airlines);
                if (airlineBlockStatus == 1)
                    return true;
                else
                    return false;

            }
            else
            {
                throw new AirlineNotFoundException($"Airline::{id} Not Found");
            }
        }

        public bool DeleteAirlineByName(string name)
        {
            Airline airline = _airlineRepository.GetAirlineByName(name);
            if (airline != null)
            {
                int airlineDeleteStatus = _airlineRepository.DeleteAirline(airline);
                if (airlineDeleteStatus == 1)
                    return true;
                else
                    return false;

            }
            else
            {
                throw new AirlineNotFoundException($"Airline::{name} Not Found");
            }
        }



        public List<Airline> GetAllAirlines()
        {
            return _airlineRepository.GetAirlines();
        }



    }
}
