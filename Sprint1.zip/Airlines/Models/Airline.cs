﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Airlines.Models
{
    public class Airline
    {
        #region Properties
        [JsonIgnore]
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }
        public string AirlineName { get; set; }

        public string FromPlace { get; set; }
        public string ToPlace { get; set; }
        public double TicketCost { get; set; }
        public int BussinessSeats { get; set; } = 20;
        public int NonBussinessSeats { get; set; } = 40;
        public bool IsBlocked { get; set; } = false;
        public string InstrumentType { get; set; }

        #endregion
    }
}
