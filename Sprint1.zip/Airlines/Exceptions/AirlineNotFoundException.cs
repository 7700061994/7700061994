﻿using System;

namespace Airlines.Exceptions
{
    public class AirlineNotFoundException : ApplicationException
    {
        public AirlineNotFoundException()
        {
        }

        public AirlineNotFoundException(string message) : base(message)
        { }
    }
}
