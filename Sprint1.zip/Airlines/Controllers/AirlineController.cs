﻿using Airlines.AOP;
using Airlines.Models;
using Airlines.Services;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Airlines.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Exceptionhandler]
    public class AirlineController : ControllerBase
    {
        readonly IAirlineService _airlineService;

        public AirlineController(IAirlineService airlineService)
        {
            _airlineService = airlineService;
        }

        [HttpPost]
        [Route("addAirline")]

        public ActionResult Airlineregister([FromBody] Airline[] airline)
        {
            bool isAirlineRegister = _airlineService.AirlineRegister(airline);
            return Ok(isAirlineRegister);
        }

        [HttpGet]
        [Route("GetAllAirlines")]
        public ActionResult GetAllAirlines()
        {
            List<Airline> airlines = _airlineService.GetAllAirlines();
            return Ok(airlines);
        }

        [HttpDelete]
        [Route("deleteAirlinebyName")]

        public ActionResult DeleteAirlineByName(string name)
        {
            bool airlineDeleteStatus = _airlineService.DeleteAirlineByName(name);
            return Ok(airlineDeleteStatus);

        }
        [HttpPut]
        [Route("BlockAirlineById")]
        public ActionResult BlockAirlineById(int id)
        {
            bool airlineDeleteStatus = _airlineService.BlockAirlineByName(id);
            return Ok(airlineDeleteStatus);

        }


    }
}
