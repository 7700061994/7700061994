﻿using FlightBooking.Models;
using Microsoft.EntityFrameworkCore;

namespace FlightBooking.Context
{
    public class BookingDbContext : DbContext
    {

        public BookingDbContext(DbContextOptions<BookingDbContext> options) : base(options)
        {
            Database.EnsureCreated();

        }

        public DbSet<FlightBook> FlightBookings { get; set; }
    }
}
