﻿using FlightBooking.Exceptions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace FlightBooking.AOP
{
    public class ExceptionhandlerAttribute : ExceptionFilterAttribute

    {
        public override void OnException(ExceptionContext context)
        {
            if (context.Exception.GetType() == typeof(BookingNotFoundException))
            {
                context.Result = new OkObjectResult(context.Exception.Message);
            }
        }
    }
}
