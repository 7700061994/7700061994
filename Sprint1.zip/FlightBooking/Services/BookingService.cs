﻿using FlightBooking.Exceptions;
using FlightBooking.Models;
using FlightBooking.Repository;
using System.Collections.Generic;

namespace FlightBooking.Services
{
    public class BookingService : IBookingService
    {
        readonly IBookingRepository _bookingRepository;

        public BookingService(IBookingRepository bookingRepository)
        {
            _bookingRepository = bookingRepository;
        }


        public FlightBook CancelBookingBefore24Hour(int pnrNo, FlightBook flightBooks)
        {
            FlightBook flightBook = _bookingRepository.GetBookingByBookingId(pnrNo);
            if (flightBook != null)
            {
                if (flightBook.BookingDate < System.DateTime.Now.AddDays(-1))
                {
                    FlightBook flightBook1 = _bookingRepository.CancelBookingBefore24Hour(pnrNo, flightBooks);
                    return flightBook1;
                }
                else
                    throw new BookingTimeExceededException($"PnrNo::{pnrNo} Exceed the Time");
            }
            else
            {
                throw new BookingNotFoundException($"PNR No::{pnrNo} Not Found");
            }
            
        }

        public bool DeleteBookingByBookingId(int pnrNo)
        {
            FlightBook flightBook = _bookingRepository.GetBookingByBookingId(pnrNo);
            if (flightBook != null)
            {
                int CancelBookingResult = _bookingRepository.DeleteBooking(flightBook);
                if (CancelBookingResult == 1)
                    return true;
                else
                    return false;

            }
            else
            {
                throw new BookingNotFoundException($"PNR No::{pnrNo} Not Found");
            }
        }

        public bool FlightBooking(FlightBook[] flightBooks)
        {
            return _bookingRepository.FlightBooking(flightBooks);
        }

        public FlightBook GetBookingByBookingId(int BookingId)
        {
            var BookingExist = _bookingRepository.GetBookingByBookingId(BookingId);
            if (BookingExist != null)
                return BookingExist;
            else
                throw new BookingNotFoundException($"Booking {BookingId} Not Found");
        }

        public List<FlightBook> GetbookingByEmailId(string Emailid)
        {
            return _bookingRepository.GetBookingByEmailId(Emailid);
        }
    }
}
