﻿using FlightBooking.Models;
using System.Collections.Generic;


namespace FlightBooking.Services
{
    public interface IBookingService
    {
        List<FlightBook> GetbookingByEmailId(string Emailid);

        bool DeleteBookingByBookingId(int BookingId);

        FlightBook GetBookingByBookingId(int BookingId);
        bool FlightBooking(FlightBook[] flightBooks);
        FlightBook CancelBookingBefore24Hour(int pnrNo, FlightBook flightBooks);
    }
}
