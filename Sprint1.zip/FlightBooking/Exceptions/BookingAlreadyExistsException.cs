﻿using System;
using System.Runtime.Serialization;

namespace FlightBooking.Exceptions
{
    [Serializable]
    public class BookingAlreadyExistsException : ApplicationException
    {
        public BookingAlreadyExistsException()
        {

        }
        public BookingAlreadyExistsException(string message) : base(message)
        {

        }
        public BookingAlreadyExistsException(string message, Exception innerException) : base(message, innerException)
        {

        }
        public BookingAlreadyExistsException(SerializationInfo info, StreamingContext context) : base(info, context)
        {

        }
    }
}
