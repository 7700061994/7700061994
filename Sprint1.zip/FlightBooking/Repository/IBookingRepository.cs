﻿
using FlightBooking.Models;
using System.Collections.Generic;

namespace FlightBooking.Repository
{
    public interface IBookingRepository
    {
        List<FlightBook> GetBookingByEmailId(string Email);

        FlightBook GetBookingByBookingId(int BookingId);

        int DeleteBooking(FlightBook flightBook);
        bool FlightBooking(FlightBook[] flightBooks);
        FlightBook CancelBookingBefore24Hour(int pnrNo, FlightBook flightBooks);
    }
}
