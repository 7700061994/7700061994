﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace FlightBooking.Models
{
    public class FlightBook
    {
        #region Properties
        [JsonIgnore]
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }
        public int PnrNo { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Gender { get; set; }
        public string FromPlace { get; set; }
        public string ToPlace { get; set; }
        public DateTime BookingDate { get; set; }
        public DateTime BookingTime { get; set; }

        public bool IsCancel { get; set; }


        #endregion
    }
}
